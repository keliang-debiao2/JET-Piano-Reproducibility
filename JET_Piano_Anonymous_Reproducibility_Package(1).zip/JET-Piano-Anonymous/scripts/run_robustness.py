#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import soundfile as sf
import torch
import yaml

from jet_piano.data.datasets import read_audio
from jet_piano.evaluation.io import maestro_reference
from jet_piano.evaluation.metrics import recording_metrics
from jet_piano.evaluation.robustness import additive_noise, contiguous_frame_mask, random_equalization
from jet_piano.inference.pipeline import decode_fused, encode_performance, load_checkpoint


def mp3_roundtrip(waveform: np.ndarray, sample_rate: int, bitrate: str = "64k") -> np.ndarray:
    with tempfile.TemporaryDirectory() as directory:
        source = Path(directory) / "source.wav"; encoded = Path(directory) / "encoded.mp3"; decoded = Path(directory) / "decoded.wav"
        sf.write(source, waveform, sample_rate)
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", str(source), "-b:a", bitrate, str(encoded)], check=True)
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", str(encoded), str(decoded)], check=True)
        result, rate = sf.read(decoded, dtype="float32")
        if rate != sample_rate: raise RuntimeError("FFmpeg changed the target sample rate")
        return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate frozen models under prespecified perturbations")
    parser.add_argument("--runs", nargs=5, required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--maestro-root", default=os.environ.get("MAESTRO_ROOT"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if not args.maestro_root: raise SystemExit("Set --maestro-root or MAESTRO_ROOT")
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    manifest = pd.read_csv(args.manifest); device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    conditions = ["clean", "noise_20db", "noise_10db", "mp3_64kbps", "equalization_6db", "frame_mask_10pct"]
    rows = []
    for run_name in args.runs:
        run = Path(run_name); config = yaml.safe_load((run / "resolved_config.yaml").read_text())
        fold = int(config["fold_config"]["fold"]); threshold = json.loads((run / "threshold.json").read_text())["onset_threshold"]
        calibration = json.loads((run / "calibration.json").read_text()); model = load_checkpoint(run / "checkpoint_best.pt", config, device)
        sample_rate = int(config["data"]["sample_rate"])
        for _, row in manifest[manifest.outer_fold == fold].iterrows():
            clean = read_audio(Path(args.maestro_root) / row.audio_path, sample_rate); reference = maestro_reference(Path(args.maestro_root) / row.label_path)
            variants = {
                "clean": (torch.from_numpy(clean), None),
                "noise_20db": (additive_noise(torch.from_numpy(clean).unsqueeze(0), 20.0)[0], None),
                "noise_10db": (additive_noise(torch.from_numpy(clean).unsqueeze(0), 10.0)[0], None),
                "mp3_64kbps": (torch.from_numpy(mp3_roundtrip(clean, sample_rate)), None),
                "equalization_6db": (torch.from_numpy(random_equalization(clean, sample_rate, 6.0, fold)), None),
                "frame_mask_10pct": (torch.from_numpy(clean), lambda features: contiguous_frame_mask(features, 0.10)),
            }
            for condition in conditions:
                waveform, transform = variants[condition]
                fused = encode_performance(model, waveform, config, device, feature_transform=transform)
                estimate = decode_fused(model, fused, threshold, calibration["temperature"], calibration["conformal_quantile"], include_velocity=True)
                rows.append({"recording_id": row.recording_id, "work_id": row.work_id, "outer_fold": fold, "condition": condition, **recording_metrics(reference, estimate)})
    metrics = pd.DataFrame(rows); metrics.to_csv(output / "recording_metrics.csv", index=False)
    metrics.groupby("condition").mean(numeric_only=True).reset_index().to_csv(output / "robustness_summary.csv", index=False)
    print(metrics.groupby("condition").mean(numeric_only=True))


if __name__ == "__main__":
    main()
