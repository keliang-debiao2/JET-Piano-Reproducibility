#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import yaml
import pandas as pd

from jet_piano.config import apply_dotted_overrides, load_config


def main() -> None:
    parser = argparse.ArgumentParser(description="Retrain every component ablation on all five outer folds")
    parser.add_argument("--config", required=True)
    parser.add_argument("--matrix", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--maestro-root", default=None)
    parser.add_argument("--musicnet-manifest", default=None)
    parser.add_argument("--musicnet-root", default=None)
    parser.add_argument("--output", required=True)
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    base = load_config(args.config); matrix = load_config(args.matrix)["variants"]
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    script_root = Path(__file__).resolve().parent
    plan = []
    summary_rows = []
    for variant, specification in matrix.items():
        config = apply_dotted_overrides(base, specification.get("overrides", {}))
        config_path = output / variant / "config.yaml"; config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
        runs = []
        for fold in range(1, 6):
            run = output / variant / f"fold_{fold}"
            runs.append(run)
            command = [sys.executable, str(script_root / "train_fold.py"), "--config", str(config_path), "--fold-config", f"configs/folds/fold_{fold}.yaml", "--manifest", args.manifest, "--output", str(run)]
            if args.maestro_root: command.extend(["--maestro-root", args.maestro_root])
            plan.append(command)
            if not args.plan_only: subprocess.run(command, check=True)
            calibrate = [sys.executable, str(script_root / "calibrate_fold.py"), "--run-dir", str(run), "--manifest", args.manifest, "--output", str(run / "calibration.json")]
            if args.maestro_root: calibrate.extend(["--maestro-root", args.maestro_root])
            plan.append(calibrate)
            if not args.plan_only: subprocess.run(calibrate, check=True)
        internal = output / variant / "internal"
        evaluate = [sys.executable, str(script_root / "evaluate_internal.py"), "--runs", *map(str, runs), "--manifest", args.manifest, "--output", str(internal)]
        if args.maestro_root: evaluate.extend(["--maestro-root", args.maestro_root])
        plan.append(evaluate)
        if not args.plan_only:
            subprocess.run(evaluate, check=True)
            metrics = json.loads((internal / "summary.json").read_text())
            row = {"variant": variant}
            for name in ("onset_f1", "onset_offset_f1", "velocity_aware_f1", "velocity_ccc"):
                if name in metrics:
                    row[f"{name}_mean"] = metrics[name]["mean"]
                    row[f"{name}_sd"] = metrics[name]["sd"]
            if args.musicnet_manifest:
                external = output / variant / "external_musicnet"
                external_command = [sys.executable, str(script_root / "evaluate_external.py"), "--runs", *map(str, runs), "--manifest", args.musicnet_manifest, "--output", str(external), "--zero-shot"]
                if args.musicnet_root: external_command.extend(["--musicnet-root", args.musicnet_root])
                plan.append(external_command); subprocess.run(external_command, check=True)
                external_metrics = json.loads((external / "summary.json").read_text())
                row["musicnet_onset_f1"] = external_metrics["metrics"]["onset_f1"]["mean"]
            summary_rows.append(row)
    if summary_rows:
        pd.DataFrame(summary_rows).to_csv(output / "ablation_summary.csv", index=False)
    (output / "execution_plan.txt").write_text("\n".join(" ".join(command) for command in plan) + "\n", encoding="utf-8")
    print(f"Prepared {len(plan)} execution commands across {len(matrix)} variants")


if __name__ == "__main__":
    main()
