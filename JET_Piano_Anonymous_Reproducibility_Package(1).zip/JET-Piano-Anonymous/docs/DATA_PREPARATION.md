# Data Preparation and Leakage Control

## Dataset acquisition

Use the unmodified public MAESTRO v3.0.0 and MusicNet v1.0 archives. Do not commit audio, MIDI, label CSV files, extracted features, or archive credentials. Record the archive filename, source URL, download date, and SHA-256 checksum in a local provenance record.

## MAESTRO manifest

`scripts/build_manifests.py` reads the official MAESTRO metadata CSV and creates one row per paired performance. Required fields are:

| Field | Meaning |
| --- | --- |
| `recording_id` | Stable hash-derived identifier; never a local absolute path |
| `audio_path` | Path relative to `MAESTRO_ROOT` |
| `label_path` | MIDI path relative to `MAESTRO_ROOT` |
| `composer` and `title` | Original metadata strings |
| `composer_normalized` | Unicode-normalized, lower-case composer key |
| `work_normalized` | Normalized title after movement, punctuation, catalogue, and whitespace handling |
| `work_id` | Hash of normalized composer and work keys |
| `year` | Recording year supplied by MAESTRO |
| `duration_s` | Audited audio duration |
| `pitch_density` | Notes per second computed from MIDI |
| `audio_sha256` and `label_sha256` | Duplicate and provenance audit fields |

The expected audit count is 1,276 paired performances. A count mismatch stops the strict pipeline and requires documented investigation.

## MusicNet solo-piano manifest

MusicNet instrument identifier 1 is piano in the original release. A recording is retained only when every labelled note belongs to the piano class and the required audio/label pair is present. The study manifest contains 156 recordings. Composer and catalogue/work strings are normalized before hashing; the resulting manifest must contain 62 `work_cluster_id` values.

MusicNet end times are score-aligned interval endpoints. They are not treated as equivalent to Disklavier key release or pedal-extended sounding offset. Velocity, CC64, and key-release targets are marked unavailable.

## Normalization rules

The normalizer performs Unicode NFKD decomposition, ASCII folding, lower-casing, punctuation removal, whitespace collapse, movement-token normalization, and conservative catalogue-number normalization. It does not use audio or target outcomes. Ambiguous titles remain separate unless composer, normalized title, and catalogue evidence agree.

The exact normalized key is stored in the manifest. Manual merges, if any, must be listed in a version-controlled override CSV with `source_key`, `target_key`, and `reason`; silent editing is prohibited.

## Fold construction

Outer folds are assigned before segment extraction. The indivisible unit is `work_id`, not recording or segment. A deterministic greedy stratifier balances:

- performance count;
- recording-year distribution;
- duration quintile;
- pitch-density quintile.

The expected fold sizes are 255, 255, 255, 255, and 256 performances, with 104-108 normalized work groups in each fold. No `work_id`, audio checksum, or label checksum may occur in more than one outer fold.

For each outer fold, the remaining work groups are divided into three inner folds plus a disjoint calibration subset. Imputation, feature normalization, hyperparameter selection, checkpoint selection, onset-threshold selection, temperature fitting, and conformal-quantile estimation use development data only.

## Segmentation

Audio is resampled to mono 22.05 kHz after fold assignment. Training uses 20-s analysis centers with 2-s left and right context and 50% overlap. Segment records retain `recording_id`, `work_id`, frame start/end, valid-center start/end, and outer/inner/calibration membership. A segment never becomes an independent splitting unit.

## Required audits

Run:

```bash
python scripts/validate_package.py --manifests manifests
```

The package validator checks manifest count expectations, outer-fold separation of
normalized work identities and available checksums, duplicate recording IDs, and
the MusicNet work-cluster count. Dataset construction additionally rejects missing
audio/label pairs and invalid metadata while building the manifests. Before
training, inspect the generated audit report for invalid pitches and non-positive
note intervals; any failed strict check must block training rather than be repaired
by silently editing the manifest.
