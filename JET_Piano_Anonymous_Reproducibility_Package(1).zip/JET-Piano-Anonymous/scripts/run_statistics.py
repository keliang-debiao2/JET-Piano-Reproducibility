#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from jet_piano.evaluation.statistics import cluster_bootstrap_difference, paired_wilcoxon_holm, rank_biserial


def comparison(name: str, jet_path: str, comparator_path: str, cluster: str, metric: str, resamples: int) -> tuple[dict[str, object], np.ndarray, np.ndarray]:
    jet = pd.read_csv(jet_path)[["recording_id", cluster, metric]].rename(columns={metric: "jet"})
    comparator = pd.read_csv(comparator_path)[["recording_id", metric]].rename(columns={metric: "comparator"})
    merged = jet.merge(comparator, on="recording_id", validate="one_to_one")
    result = cluster_bootstrap_difference(merged, cluster, "jet", "comparator", resamples)
    difference = merged.groupby(cluster)[["jet", "comparator"]].mean().eval("jet - comparator").to_numpy()
    row = {"comparison": name, "metric": metric, "mean_difference": result["mean_difference"], "ci95_low": result["ci95"][0], "ci95_high": result["ci95"][1], "rank_biserial": rank_biserial(difference), "clusters": len(difference)}
    return row, difference, np.asarray(result["bootstrap"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Six prespecified paired work-cluster comparisons")
    parser.add_argument("--jet-internal", required=True)
    parser.add_argument("--transkun-internal", required=True)
    parser.add_argument("--hft-internal", required=True)
    parser.add_argument("--jet-external", required=True)
    parser.add_argument("--transkun-external", required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    specs = [
        ("MAESTRO onset F1 vs TransKun v2", args.jet_internal, args.transkun_internal, "work_id", "onset_f1"),
        ("MAESTRO onset+offset F1 vs TransKun v2", args.jet_internal, args.transkun_internal, "work_id", "onset_offset_f1"),
        ("MAESTRO velocity-aware F1 vs TransKun v2", args.jet_internal, args.transkun_internal, "work_id", "velocity_aware_f1"),
        ("MAESTRO velocity CCC vs hFT-Transformer", args.jet_internal, args.hft_internal, "work_id", "velocity_ccc"),
        ("MusicNet onset F1 vs TransKun v2", args.jet_external, args.transkun_external, "work_cluster_id", "onset_f1"),
        ("MusicNet onset+offset F1 vs TransKun v2", args.jet_external, args.transkun_external, "work_cluster_id", "onset_offset_f1"),
    ]
    rows, differences, bootstrap_arrays = [], [], {}
    for name, jet, comparator, cluster, metric in specs:
        row, diff, boot = comparison(name, jet, comparator, cluster, metric, args.bootstrap)
        rows.append(row); differences.append((name, diff)); bootstrap_arrays[f"comparison_{len(rows)}"] = boot
    tests = paired_wilcoxon_holm(differences).set_index("comparison")
    for row in rows:
        row["p_raw"] = float(tests.loc[row["comparison"], "p_raw"]); row["p_holm"] = float(tests.loc[row["comparison"], "p_holm"])
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output / "paired_comparisons.csv", index=False)
    np.savez_compressed(output / "paired_bootstrap_distributions.npz", **bootstrap_arrays)
    print(pd.DataFrame(rows))


if __name__ == "__main__":
    main()
