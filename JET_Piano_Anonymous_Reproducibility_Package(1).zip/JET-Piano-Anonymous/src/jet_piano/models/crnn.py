"""Parameter-scale CRNN control used only for the backbone ablation."""

from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


class CRNNBackbone(nn.Module):
    """Replace DTAT while preserving the downstream tensor contract."""

    def __init__(
        self,
        dim: int = 256,
        hidden: int = 512,
        layers: int = 3,
        window_frames: int = 128,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.window_frames = window_frames
        self.gru = nn.GRU(
            input_size=dim,
            hidden_size=hidden,
            num_layers=layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if layers > 1 else 0.0,
        )
        self.projection = nn.Linear(2 * hidden, dim)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        fine, _ = self.gru(x)
        fine = self.norm(self.projection(fine))
        windows = math.ceil(fine.shape[1] / self.window_frames)
        padded = F.pad(fine, (0, 0, 0, windows * self.window_frames - fine.shape[1]))
        summary = padded.view(
            fine.shape[0], windows, self.window_frames, fine.shape[2]
        ).mean(dim=2)
        context = summary.repeat_interleave(self.window_frames, dim=1)[:, : fine.shape[1]]
        return fine, summary, context
