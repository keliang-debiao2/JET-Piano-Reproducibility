"""Small dispatcher for repository-level scripts."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


COMMANDS = {
    "build-manifests": "build_manifests.py",
    "make-folds": "make_folds.py",
    "train-fold": "train_fold.py",
    "calibrate-fold": "calibrate_fold.py",
    "evaluate-internal": "evaluate_internal.py",
    "evaluate-external": "evaluate_external.py",
    "run-ablation": "run_ablation.py",
    "run-robustness": "run_robustness.py",
    "run-statistics": "run_statistics.py",
    "run-baselines": "run_baselines.py",
    "make-figures": "make_figures.py",
    "run-efficiency": "run_efficiency.py",
    "run-interpretability": "run_interpretability.py",
    "synthetic-smoke": "synthetic_smoke.py",
    "validate": "validate_package.py",
}


def main() -> None:
    parser = argparse.ArgumentParser(prog="jet-piano")
    parser.add_argument("command", choices=sorted(COMMANDS))
    args, remainder = parser.parse_known_args()
    root = Path(__file__).resolve().parents[2]
    command = [sys.executable, str(root / "scripts" / COMMANDS[args.command]), *remainder]
    raise SystemExit(subprocess.call(command))
