"""Cluster-preserving bootstrap and paired multiplicity-controlled inference."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import rankdata, wilcoxon


def cluster_bootstrap_difference(
    frame: pd.DataFrame,
    cluster_col: str,
    jet_col: str,
    comparator_col: str,
    resamples: int = 10000,
    seed: int = 20261031,
) -> dict[str, object]:
    grouped = frame.groupby(cluster_col)[[jet_col, comparator_col]].mean()
    difference = (grouped[jet_col] - grouped[comparator_col]).to_numpy(float)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(difference), size=(resamples, len(difference)))
    boot = difference[indices].mean(axis=1)
    low, high = np.quantile(boot, [0.025, 0.975])
    return {"mean_difference": float(difference.mean()), "ci95": [float(low), float(high)], "bootstrap": boot}


def rank_biserial(difference: np.ndarray) -> float:
    difference = np.asarray(difference, dtype=float)
    difference = difference[difference != 0]
    if not len(difference):
        return 0.0
    ranks = rankdata(np.abs(difference))
    return float((ranks[difference > 0].sum() - ranks[difference < 0].sum()) / ranks.sum())


def paired_wilcoxon_holm(comparisons: list[tuple[str, np.ndarray]]) -> pd.DataFrame:
    rows, p_values = [], []
    for name, difference in comparisons:
        difference = np.asarray(difference, dtype=float)
        result = wilcoxon(difference, zero_method="wilcox", alternative="two-sided")
        p_values.append(float(result.pvalue))
        rows.append({"comparison": name, "mean_difference": float(difference.mean()), "rank_biserial": rank_biserial(difference), "p_raw": float(result.pvalue)})
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        value = min(1.0, (len(p_values) - rank) * p_values[index])
        running = max(running, value)
        adjusted[index] = running
    for row, value in zip(rows, adjusted):
        row["p_holm"] = float(value)
    return pd.DataFrame(rows)
