import torch

from jet_piano.models.paces import KEY, PACES


def test_paces_cannot_start_key_without_candidate():
    decoder = PACES(dim=8, pitches=2, duration_frames=4)
    unary = torch.zeros(1, 5, 2, 3)
    unary[..., KEY] = 10.0
    onset = torch.zeros(1, 5, 2)
    pedal = torch.zeros(1, 5)
    no_candidate = torch.zeros_like(onset, dtype=torch.bool)
    result = decoder.viterbi_decode(unary, onset, no_candidate, pedal)[0]
    assert not torch.any(result.states == KEY)
    candidate = no_candidate.clone(); candidate[:, 2, 0] = True
    result = decoder.viterbi_decode(unary, onset, candidate, pedal)[0]
    assert result.states[2, 0] == KEY
