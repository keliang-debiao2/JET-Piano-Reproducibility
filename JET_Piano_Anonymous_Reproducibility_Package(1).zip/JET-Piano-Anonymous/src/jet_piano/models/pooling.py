"""Pitch-conditioned proposal generation, suppression, and event pooling."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class OnsetGuidedEventPool(nn.Module):
    def __init__(
        self,
        dim: int = 256,
        pitches: int = 88,
        width_frames: float = 3.0,
        neighborhood_frames: int = 5,
    ) -> None:
        super().__init__()
        self.pitches = pitches
        self.width_frames = width_frames
        self.neighborhood_frames = neighborhood_frames
        self.proposal = nn.Linear(dim, pitches)

    def forward_logits(self, fine: torch.Tensor) -> torch.Tensor:
        return self.proposal(fine)

    def select_candidates(self, logits: torch.Tensor, threshold: float) -> list[torch.Tensor]:
        """Return per-batch tensors with columns `[frame, pitch_index, probability]`."""
        probabilities = logits.sigmoid()
        pooled = F.max_pool1d(
            probabilities.transpose(1, 2),
            kernel_size=self.neighborhood_frames,
            stride=1,
            padding=self.neighborhood_frames // 2,
        ).transpose(1, 2)
        maxima = probabilities.eq(pooled) & probabilities.gt(threshold)
        output = []
        for batch_index in range(logits.shape[0]):
            frame, pitch = torch.where(maxima[batch_index])
            probability = probabilities[batch_index, frame, pitch]
            order = torch.argsort(frame * self.pitches + pitch)
            output.append(torch.stack([frame[order], pitch[order], probability[order]], dim=1))
        return output

    @staticmethod
    def suppress_same_pitch(candidates: torch.Tensor, tolerance_frames: int = 4) -> torch.Tensor:
        if candidates.numel() == 0:
            return candidates
        kept = []
        for pitch in candidates[:, 1].long().unique(sorted=True):
            subset = candidates[candidates[:, 1].long() == pitch]
            subset = subset[torch.argsort(subset[:, 0])]
            current = subset[0]
            for row in subset[1:]:
                if int(row[0] - current[0]) <= tolerance_frames:
                    if row[2] > current[2]:
                        current = row
                else:
                    kept.append(current)
                    current = row
            kept.append(current)
        return torch.stack(kept)[torch.argsort(torch.stack(kept)[:, 0])]

    def pool(
        self,
        fine: torch.Tensor,
        onset_logits: torch.Tensor,
        candidates: list[torch.Tensor],
        uniform: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        event_tokens, event_batch, event_frame, event_pitch = [], [], [], []
        for batch_index, candidate_set in enumerate(candidates):
            for row in candidate_set:
                center = int(row[0].item())
                pitch = int(row[1].item())
                radius = max(1, int(round(3 * self.width_frames)))
                left = max(0, center - radius)
                right = min(fine.shape[1], center + radius + 1)
                positions = torch.arange(left, right, device=fine.device, dtype=fine.dtype)
                gaussian = torch.exp(-0.5 * ((positions - center) / self.width_frames) ** 2)
                if uniform:
                    weights = gaussian
                else:
                    weights = gaussian * onset_logits[batch_index, left:right, pitch].sigmoid()
                weights = weights / weights.sum().clamp_min(1e-8)
                event_tokens.append((fine[batch_index, left:right] * weights[:, None]).sum(dim=0))
                event_batch.append(batch_index)
                event_frame.append(center)
                event_pitch.append(pitch)
        if not event_tokens:
            empty = fine.new_zeros((0, fine.shape[-1]))
            empty_index = torch.zeros(0, device=fine.device, dtype=torch.long)
            return empty, empty_index, empty_index, empty_index
        return (
            torch.stack(event_tokens),
            torch.tensor(event_batch, device=fine.device, dtype=torch.long),
            torch.tensor(event_frame, device=fine.device, dtype=torch.long),
            torch.tensor(event_pitch, device=fine.device, dtype=torch.long),
        )
