#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from jet_piano.data.manifests import build_maestro_manifest, build_musicnet_manifest
from jet_piano.utils import sha256_file, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Build audited MAESTRO and MusicNet manifests")
    parser.add_argument("--maestro-root", required=True)
    parser.add_argument("--musicnet-root", required=True)
    parser.add_argument("--out-dir", default="manifests")
    parser.add_argument("--non-strict", action="store_true")
    args = parser.parse_args()
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    maestro = build_maestro_manifest(args.maestro_root, strict=not args.non_strict)
    musicnet = build_musicnet_manifest(args.musicnet_root, strict=not args.non_strict)
    maestro_path = out / "maestro_manifest.csv"; musicnet_path = out / "musicnet_solo_piano_manifest.csv"
    maestro.to_csv(maestro_path, index=False); musicnet.to_csv(musicnet_path, index=False)
    summary = {
        "maestro": {"recordings": len(maestro), "work_groups": int(maestro.work_id.nunique()), "duration_h": float(maestro.duration_s.sum() / 3600), "manifest_sha256": sha256_file(maestro_path)},
        "musicnet": {"recordings": len(musicnet), "work_clusters": int(musicnet.work_cluster_id.nunique()), "duration_h": float(musicnet.duration_s.sum() / 3600), "manifest_sha256": sha256_file(musicnet_path)},
    }
    write_json(out / "dataset_characteristics.json", summary)
    print(summary)


if __name__ == "__main__":
    main()
