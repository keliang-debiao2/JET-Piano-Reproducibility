"""Dual-timescale acoustic tokenizer with local fine tokens and global summaries."""

from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


class DTATLayer(nn.Module):
    def __init__(
        self,
        dim: int,
        heads: int,
        feedforward_dim: int,
        window_frames: int,
        dropout: float,
        disable_summary_exchange: bool = False,
    ) -> None:
        super().__init__()
        self.dim = dim
        self.window_frames = window_frames
        self.disable_summary_exchange = disable_summary_exchange
        self.local_norm = nn.LayerNorm(dim)
        self.local_attn = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        self.summary_norm = nn.LayerNorm(dim)
        self.summary_attn = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        self.summary_to_fine = nn.Linear(dim, dim)
        self.ffn_norm = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, feedforward_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(feedforward_dim, dim), nn.Dropout(dropout),
        )

    def forward(self, fine: torch.Tensor, summary: torch.Tensor | None = None) -> tuple[torch.Tensor, torch.Tensor]:
        batch, frames, dim = fine.shape
        windows = math.ceil(frames / self.window_frames)
        padded_frames = windows * self.window_frames
        padded = F.pad(fine, (0, 0, 0, padded_frames - frames))
        local = padded.view(batch * windows, self.window_frames, dim)
        local_norm = self.local_norm(local)
        attended, _ = self.local_attn(local_norm, local_norm, local_norm, need_weights=False)
        local = local + attended
        local = local.view(batch, windows, self.window_frames, dim)
        pooled = local.mean(dim=2)
        if summary is None:
            summary = pooled
        else:
            summary = summary + pooled
        if not self.disable_summary_exchange:
            normalized = self.summary_norm(summary)
            exchanged, _ = self.summary_attn(normalized, normalized, normalized, need_weights=False)
            summary = summary + exchanged
            local = local + self.summary_to_fine(summary).unsqueeze(2)
        merged = local.reshape(batch, padded_frames, dim)[:, :frames]
        merged = merged + self.ffn(self.ffn_norm(merged))
        return merged, summary


class DualTimescaleAcousticTokenizer(nn.Module):
    def __init__(
        self,
        dim: int = 256,
        layers: int = 6,
        heads: int = 8,
        feedforward_dim: int = 1024,
        window_frames: int = 128,
        dropout: float = 0.1,
        disable_summary_exchange: bool = False,
    ) -> None:
        super().__init__()
        self.window_frames = window_frames
        self.layers = nn.ModuleList(
            DTATLayer(
                dim, heads, feedforward_dim, window_frames, dropout, disable_summary_exchange
            )
            for _ in range(layers)
        )
        self.output_norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        summary = None
        for layer in self.layers:
            x, summary = layer(x, summary)
        x = self.output_norm(x)
        summary = self.output_norm(summary)
        context = summary.repeat_interleave(self.window_frames, dim=1)[:, : x.shape[1]]
        return x, summary, context
