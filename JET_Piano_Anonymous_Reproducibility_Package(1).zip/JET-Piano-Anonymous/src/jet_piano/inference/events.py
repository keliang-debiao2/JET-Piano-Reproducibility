"""Convert PACES state sequences and CERD attributes into event records."""

from __future__ import annotations

from dataclasses import dataclass, asdict

import numpy as np

from jet_piano.models.paces import KEY, OFF, PEDAL


@dataclass
class EventRecord:
    pitch: int
    onset_s: float
    key_release_s: float
    sounding_offset_s: float
    velocity: float | None = None
    velocity_scale_normalized: float | None = None
    confidence: float | None = None
    velocity_lower: float | None = None
    velocity_upper: float | None = None


def state_paths_to_events(states: np.ndarray, hop_seconds: float, midi_min: int = 21) -> list[EventRecord]:
    if states.ndim != 2:
        raise ValueError("State array must have shape [frames, pitches]")
    events: list[EventRecord] = []
    for pitch_index in range(states.shape[1]):
        onset = None
        key_release = None
        previous = OFF
        for frame, current in enumerate(states[:, pitch_index].astype(int)):
            if previous in (OFF, PEDAL) and current == KEY:
                if onset is not None:
                    events.append(EventRecord(midi_min + pitch_index, onset * hop_seconds, (key_release or frame) * hop_seconds, frame * hop_seconds))
                onset, key_release = frame, None
            elif previous == KEY and current == PEDAL:
                key_release = frame
            elif previous == KEY and current == OFF and onset is not None:
                events.append(EventRecord(midi_min + pitch_index, onset * hop_seconds, frame * hop_seconds, frame * hop_seconds))
                onset, key_release = None, None
            elif previous == PEDAL and current == OFF and onset is not None:
                events.append(EventRecord(midi_min + pitch_index, onset * hop_seconds, (key_release or frame) * hop_seconds, frame * hop_seconds))
                onset, key_release = None, None
            previous = current
        if onset is not None:
            frame = states.shape[0]
            events.append(EventRecord(midi_min + pitch_index, onset * hop_seconds, (key_release or frame) * hop_seconds, frame * hop_seconds))
    return sorted(events, key=lambda event: (event.onset_s, event.pitch))


def events_as_dicts(events: list[EventRecord]) -> list[dict[str, float | int | None]]:
    return [asdict(event) for event in events]
