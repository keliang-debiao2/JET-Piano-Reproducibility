# JET-Piano Anonymous Reproducibility Package

This repository contains the implementation scaffold and evaluation pipeline for **JET-Piano: Dual-Timescale Event-State Learning for Structured Note Transcription and Velocity-Aware Performance Analysis in Real Piano Performances**. It is prepared for double-anonymous review: no author names, affiliations, local machine paths, account names, or private data are included.

## Scope and evidence status

The code implements the paper's complete computational path:

1. MAESTRO v3.0.0 and MusicNet manifest construction and data auditing;
2. normalized-work grouping and leakage-controlled five-fold splitting;
3. 22.05-kHz log-Mel plus Bark-loudness feature extraction;
4. the DTAT, onset-guided pooling, PACES, CERD, and GRCT components;
5. fold-specific training, calibration, split-conformal velocity intervals, and frozen inference;
6. internal validation, zero-shot MusicNet evaluation, ablation, robustness, clustered bootstrap, paired testing, interpretability, efficiency reporting, and figure/table export.

Two kinds of logs are intentionally separated:

- `logs/synthetic_smoke/` contains a real, lightweight structural smoke-test record generated from synthetic tensors. It validates code paths only and is not a scientific result.
- `logs/simulated_reference/` contains **SIMULATED REFERENCE LOGS** whose values mirror the manuscript tables. They are supplied only as target schemas and expected numerical ranges for independent reproduction. They must never be represented as hardware-generated experimental evidence and should be replaced by actual run outputs before archival release.

No audio, MIDI, MusicNet labels, trained weights, or third-party baseline checkpoints are redistributed.

## Repository layout

```text
configs/                    Frozen model, training, fold, and ablation settings
docs/                       Data preparation and reproduction protocol
examples/                   Manifest-schema examples without dataset content
logs/simulated_reference/  Clearly labelled manuscript-aligned target logs
logs/synthetic_smoke/       Structural smoke-test log
manifests/                  Generated manifests, folds, and checksums (local)
scripts/                    End-to-end command-line entry points
src/jet_piano/              Model, data, training, inference, and evaluation code
tests/                      Leakage, fusion, decoder, calibration, and metric tests
```

## 1. Environment

The reference environment uses Python 3.11 and CUDA 12.1-compatible PyTorch. Create it with either Conda or pip:

```bash
conda env create -f environment.yml
conda activate jet-piano
pip install -e .
```

or

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
```

Run the fast checks before using real data:

```bash
python scripts/validate_package.py --strict-anonymous \
  --output logs/synthetic_smoke/package_validation.json
pytest -q
python scripts/synthetic_smoke.py --config configs/base.yaml
```

## 2. Public datasets

Download the datasets from their official sources and retain their original directory structures.

- MAESTRO v3.0.0: <https://magenta.tensorflow.org/datasets/maestro>
- MusicNet v1.0 archive: <https://doi.org/10.5281/zenodo.5120004>

Dataset use remains subject to the terms distributed with each archive. This repository does not alter or redistribute those materials.

Set local paths without committing them:

```bash
export MAESTRO_ROOT=/absolute/path/to/maestro-v3.0.0
export MUSICNET_ROOT=/absolute/path/to/musicnet
export JET_OUTPUT_ROOT=/absolute/path/to/jet-piano-runs
```

Detailed schema and audit rules are in `docs/DATA_PREPARATION.md`.
The MP3 robustness condition additionally requires `ffmpeg` on `PATH`.

## 3. Build manifests and grouped folds

```bash
python scripts/build_manifests.py \
  --maestro-root "$MAESTRO_ROOT" \
  --musicnet-root "$MUSICNET_ROOT" \
  --out-dir manifests

python scripts/make_folds.py \
  --manifest manifests/maestro_manifest.csv \
  --out manifests/maestro_folds.csv \
  --n-folds 5 \
  --seed 20261031
```

The fold script treats normalized composer-work identity as indivisible. Segmentation happens after fold assignment. `scripts/validate_package.py --manifests manifests` fails if a recording, normalized work, or checksum crosses an outer-fold boundary.

## 4. Five-fold model development

Train one outer fold at a time. Hyperparameters are selected only from grouped inner folds; the calibration subset is held out from gradient updates.

```bash
for fold in 1 2 3 4 5; do
  python scripts/train_fold.py \
    --config configs/base.yaml \
    --fold-config configs/folds/fold_${fold}.yaml \
    --manifest manifests/maestro_folds.csv \
    --output "$JET_OUTPUT_ROOT/fold_${fold}"

  python scripts/calibrate_fold.py \
    --run-dir "$JET_OUTPUT_ROOT/fold_${fold}" \
    --output "$JET_OUTPUT_ROOT/fold_${fold}/calibration.json"
done
```

The training command stores the resolved configuration, source revision, manifest checksum, fold membership, random seed, checkpoint-selection trace, and epoch-level JSONL log with every checkpoint.

## 5. Internal out-of-fold evaluation

```bash
python scripts/evaluate_internal.py \
  --runs "$JET_OUTPUT_ROOT/fold_1" "$JET_OUTPUT_ROOT/fold_2" \
         "$JET_OUTPUT_ROOT/fold_3" "$JET_OUTPUT_ROOT/fold_4" \
         "$JET_OUTPUT_ROOT/fold_5" \
  --manifest manifests/maestro_folds.csv \
  --output "$JET_OUTPUT_ROOT/internal"
```

Each performance receives exactly one out-of-fold prediction. Macro metrics are computed at recording level. Paired inferential resampling uses normalized work clusters rather than treating recordings as independent.

## 6. Strict zero-shot MusicNet validation

```bash
python scripts/evaluate_external.py \
  --runs "$JET_OUTPUT_ROOT/fold_1" "$JET_OUTPUT_ROOT/fold_2" \
         "$JET_OUTPUT_ROOT/fold_3" "$JET_OUTPUT_ROOT/fold_4" \
         "$JET_OUTPUT_ROOT/fold_5" \
  --manifest manifests/musicnet_solo_piano_manifest.csv \
  --output "$JET_OUTPUT_ROOT/external_musicnet" \
  --zero-shot
```

For every checkpoint, overlapping window outputs are Hann-fused on the recording timeline. The five checkpoints are then averaged framewise; learned transition and duration parameters are averaged elementwise; the arithmetic mean of the five MAESTRO-selected onset thresholds is applied; and one recording-level Viterbi pass is run. MusicNet labels never select a checkpoint, threshold, decoder parameter, or aggregation weight.

## 7. Ablation, robustness, and inference statistics

```bash
python scripts/run_ablation.py --config configs/base.yaml \
  --matrix configs/ablations.yaml --manifest manifests/maestro_folds.csv \
  --output "$JET_OUTPUT_ROOT/ablations"

python scripts/run_robustness.py \
  --runs "$JET_OUTPUT_ROOT/fold_1" "$JET_OUTPUT_ROOT/fold_2" \
         "$JET_OUTPUT_ROOT/fold_3" "$JET_OUTPUT_ROOT/fold_4" \
         "$JET_OUTPUT_ROOT/fold_5" \
  --manifest manifests/maestro_folds.csv \
  --output "$JET_OUTPUT_ROOT/robustness"

python scripts/run_statistics.py \
  --jet-internal "$JET_OUTPUT_ROOT/internal/recording_metrics.csv" \
  --transkun-internal "$JET_OUTPUT_ROOT/baselines/transkun/recording_metrics.csv" \
  --hft-internal "$JET_OUTPUT_ROOT/baselines/hft/recording_metrics.csv" \
  --jet-external "$JET_OUTPUT_ROOT/external_musicnet/recording_metrics.csv" \
  --transkun-external "$JET_OUTPUT_ROOT/baselines/transkun_musicnet/recording_metrics.csv" \
  --bootstrap 10000 \
  --output "$JET_OUTPUT_ROOT/statistics"
```

The ablation driver retrains every requested variant on all five outer folds. Statistical outputs include paired cluster-bootstrap confidence intervals, Wilcoxon signed-rank tests, Holm correction, and rank-biserial effects.

## 8. Expected outputs

Each run directory contains:

```text
resolved_config.yaml
run_metadata.json
manifest.sha256
feature_normalization.pt
train.jsonl
checkpoint_best.pt
threshold.json
calibration.json
predictions/events.parquet
metrics/recording_metrics.csv
metrics/summary.json
```

The mapping from output files to manuscript tables and figures is documented in `docs/RESULT_MAPPING.md`.
After actual result files have been generated, reproduce Figures 3--8 with
`python scripts/make_figures.py --results-root "$JET_OUTPUT_ROOT" --output "$JET_OUTPUT_ROOT/figures"`.

## Baseline policy

Classical, compact-neural, and third-party baseline event exports can be rescored
through `scripts/run_baselines.py`. Architectures whose official implementations and
pretrained weights are maintained by third parties are evaluated through the
common event-CSV adapter rather than copied into this repository.  Exact source
revisions, licenses, input/output schemas, and the prohibition on using outer-test
labels for threshold selection are specified in `docs/BASELINES.md`.

## Anonymous-review checklist

Before uploading the repository:

```bash
python scripts/validate_package.py --strict-anonymous --manifests manifests
git status --short
```

Confirm that dataset paths, usernames, hostnames, access tokens, author identities, raw audio, private checkpoints, and unlabelled reference logs are absent. The simulated reference directory may remain only if its status banner is preserved and the journal permits non-empirical target artifacts; otherwise remove it after real logs have been generated.

## License

The repository code is released under the MIT License for anonymous review. Dataset licenses and third-party baseline licenses remain separate.
