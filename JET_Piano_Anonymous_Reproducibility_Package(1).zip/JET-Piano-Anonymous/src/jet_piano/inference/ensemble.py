"""Frozen five-checkpoint aggregation for strict MusicNet evaluation."""

from __future__ import annotations

import copy
from typing import Any

import torch


def arithmetic_mean_state_dicts(states: list[dict[str, torch.Tensor]]) -> dict[str, torch.Tensor]:
    if not states:
        raise ValueError("No state dictionaries supplied")
    keys = set(states[0])
    if any(set(state) != keys for state in states[1:]):
        raise ValueError("Checkpoint decoder state dictionaries have different keys")
    return {key: torch.stack([state[key].float() for state in states]).mean(dim=0) for key in keys}


def aggregate_external_checkpoints(
    checkpoint_outputs: list[dict[str, torch.Tensor]],
    decoder_states: list[dict[str, torch.Tensor]],
    onset_thresholds: list[float],
) -> dict[str, Any]:
    """Aggregate after per-checkpoint timeline fusion and before one decoder pass."""
    if not (len(checkpoint_outputs) == len(decoder_states) == len(onset_thresholds) == 5):
        raise ValueError("Strict external aggregation requires exactly five outer-fold checkpoints")
    required = {"fine", "onset_logits", "unary_logits", "pedal_logits"}
    if any(not required.issubset(output) for output in checkpoint_outputs):
        raise ValueError("Every checkpoint output must be Hann-fused before aggregation")
    shape_reference = {key: checkpoint_outputs[0][key].shape for key in required}
    for output in checkpoint_outputs[1:]:
        if any(output[key].shape != shape_reference[key] for key in required):
            raise ValueError("Checkpoint timeline shapes differ")
    averaged = {
        key: torch.stack([output[key].float() for output in checkpoint_outputs]).mean(dim=0)
        for key in required
    }
    averaged["decoder_state"] = arithmetic_mean_state_dicts(decoder_states)
    averaged["onset_threshold"] = float(sum(onset_thresholds) / len(onset_thresholds))
    averaged["decoder_passes"] = 1
    return averaged
