import torch

from jet_piano.inference.fusion import hann_fuse


def test_hann_fusion_occurs_on_aligned_timeline():
    first = torch.ones(6, 2)
    second = torch.full((6, 2), 3.0)
    fused = hann_fuse([first, second], [(0, 6), (4, 10)], 10)
    assert fused.shape == (10, 2)
    assert torch.allclose(fused[:4], torch.ones(4, 2))
    assert torch.allclose(fused[6:], torch.full((4, 2), 3.0))
    assert torch.all((fused[4:6] >= 1) & (fused[4:6] <= 3))
