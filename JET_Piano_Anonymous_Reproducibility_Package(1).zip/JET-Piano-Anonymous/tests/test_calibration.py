import numpy as np

from jet_piano.inference.calibration import SplitConformalVelocity, selective_risk


def test_split_conformal_finite_sample_quantile_and_clipping():
    target = np.array([0.1, 0.3, 0.5, 0.7, 0.9])
    mean = target + np.array([0.01, -0.02, 0.03, -0.01, 0.02])
    scale = np.full(5, 0.1)
    conformal = SplitConformalVelocity(alpha=0.1)
    assert conformal.fit(target, mean, scale) > 0
    interval = conformal.interval(np.array([0.01, 0.99]), np.array([0.2, 0.2]), midi_units=False)
    assert interval.min() >= 0 and interval.max() <= 1


def test_selective_risk_uses_accepted_predictions_only():
    result = selective_risk(np.array([0.9, 0.8, 0.2]), np.array([1, 1, 0]), np.array([2 / 3, 1.0]))
    assert result["risk"][0] == 0
    assert result["risk"][1] > 0
