"""Performance-level window fusion, decoding, confidence, and event export."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from jet_piano.inference.events import state_paths_to_events
from jet_piano.inference.fusion import hann_fuse
from jet_piano.models.jet_piano import JETPiano


@torch.no_grad()
def encode_performance(
    model: JETPiano,
    waveform: torch.Tensor,
    config: dict[str, Any],
    device: torch.device,
    feature_transform=None,
) -> dict[str, torch.Tensor]:
    data = config["data"]
    sample_rate, hop = int(data["sample_rate"]), int(data["hop_length"])
    center_samples = int(round(float(data["segment_seconds"]) * sample_rate))
    context_samples = int(round(float(data["context_seconds"]) * sample_rate))
    stride_samples = int(round(center_samples * (1.0 - float(data["overlap"]))))
    # With center=True in the acoustic front end, an N-sample waveform has
    # floor(N / hop) + 1 analysis frames.  Using the same convention here is
    # essential: a one-frame surplus would leave the final fusion denominator
    # at zero and would make windowed inference differ from full-recording
    # inference.
    total_frames = waveform.numel() // hop + 1
    keys = ["fine", "summary_context", "onset_logits", "unary_logits", "pedal_logits"]
    pieces: dict[str, list[torch.Tensor]] = {key: [] for key in keys}
    ranges: list[tuple[int, int]] = []
    for valid_start in range(0, max(waveform.numel(), 1), max(stride_samples, 1)):
        valid_end = min(valid_start + center_samples, waveform.numel())
        segment_start = max(0, valid_start - context_samples)
        segment_end = min(waveform.numel(), valid_end + context_samples)
        encoded = model.encode(
            waveform[segment_start:segment_end].unsqueeze(0).to(device),
            feature_transform=feature_transform,
        )
        local_start = (valid_start - segment_start) // hop
        global_start = valid_start // hop
        global_end = min(total_frames, valid_end // hop + 1)
        length = max(1, global_end - global_start)
        local_end = min(encoded["fine"].shape[1], local_start + length)
        length = local_end - local_start; global_end = global_start + length
        ranges.append((global_start, global_end))
        for key in keys:
            pieces[key].append(encoded[key][0, local_start:local_end].cpu())
        if valid_end == waveform.numel(): break
    return {key: hann_fuse(pieces[key], ranges, total_frames).to(device).unsqueeze(0) for key in keys}


def average_fused_outputs(outputs: list[dict[str, torch.Tensor]]) -> dict[str, torch.Tensor]:
    keys = outputs[0].keys()
    return {key: torch.stack([output[key].float() for output in outputs]).mean(dim=0) for key in keys}


def average_decoder_parameters(models: list[JETPiano]) -> JETPiano:
    target = copy.deepcopy(models[0])
    state = target.state_dict()
    source_states = [model.state_dict() for model in models]
    decoder_prefixes = ("paces.",)
    for key in state:
        if key.startswith(decoder_prefixes) and state[key].is_floating_point():
            state[key] = torch.stack([source[key].float() for source in source_states]).mean(dim=0).to(state[key])
    target.load_state_dict(state)
    return target


@torch.no_grad()
def decode_fused(
    model: JETPiano,
    fused: dict[str, torch.Tensor],
    onset_threshold: float,
    temperature: float = 1.0,
    conformal_quantile: float | None = None,
    include_velocity: bool = True,
) -> pd.DataFrame:
    candidate_sets = [
        model.pooling.suppress_same_pitch(candidates, tolerance_frames=4)
        for candidates in model.pooling.select_candidates(fused["onset_logits"], onset_threshold)
    ]
    outputs = model.forward_from_encoded(fused, candidate_sets, onset_threshold)
    decoded = model.decode(outputs)[0]
    states = decoded.states if hasattr(decoded, "states") else decoded
    records = state_paths_to_events(states.detach().cpu().numpy(), model.features.frame_seconds, model.midi_min)
    attribute_map = {}
    if include_velocity:
        for index in range(outputs["event_frame"].shape[0]):
            key = (int(outputs["event_pitch"][index]) + model.midi_min, int(outputs["event_frame"][index]))
            mean = float(outputs["attribute_mean"][index, 0].sigmoid().cpu())
            scale = float((0.5 * outputs["attribute_log_variance"][index, 0]).exp().cpu())
            attribute_map[key] = (127.0 * mean, scale)
    rows = []
    for record in records:
        frame = int(round(record.onset_s / model.features.frame_seconds))
        pitch_index = record.pitch - model.midi_min
        if frame >= fused["onset_logits"].shape[1] or not 0 <= pitch_index < model.pitches: continue
        unary = fused["unary_logits"][0, frame, pitch_index]
        margin = unary[1] + model.paces.transition_bias["ok"] + fused["onset_logits"][0, frame, pitch_index] - unary[0]
        record.confidence = float(torch.sigmoid(margin / temperature).cpu())
        if include_velocity and (record.pitch, frame) in attribute_map:
            record.velocity, scale = attribute_map[(record.pitch, frame)]
            record.velocity_scale_normalized = scale
            if conformal_quantile is not None:
                normalized = record.velocity / 127.0
                record.velocity_lower = 127.0 * max(0.0, normalized - conformal_quantile * scale)
                record.velocity_upper = 127.0 * min(1.0, normalized + conformal_quantile * scale)
        rows.append(record.__dict__)
    return pd.DataFrame(rows)


def load_checkpoint(path: str | Path, config: dict[str, Any], device: torch.device) -> JETPiano:
    payload = torch.load(path, map_location=device, weights_only=False)
    model = JETPiano(config).to(device)
    model.load_state_dict(payload["model"] if "model" in payload else payload)
    model.eval()
    return model
