#!/usr/bin/env python3
"""Fit held-out linear probes to previously exported CERD codes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from jet_piano.evaluation.interpretability import pitch_probe, velocity_probe


def main() -> None:
    parser = argparse.ArgumentParser(description="Held-out CERD specialization probes")
    parser.add_argument("--train-npz", required=True)
    parser.add_argument("--test-npz", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    train, test = np.load(args.train_npz), np.load(args.test_npz)
    required = {"content", "expression", "pitch", "velocity"}
    for name, archive in (("train", train), ("test", test)):
        missing = required - set(archive.files)
        if missing: raise ValueError(f"{name} archive lacks {sorted(missing)}")
    payload = {
        "content_pitch_accuracy": pitch_probe(train["content"], train["pitch"], test["content"], test["pitch"]),
        "expression_pitch_accuracy": pitch_probe(train["expression"], train["pitch"], test["expression"], test["pitch"]),
        "expression_velocity_ccc": velocity_probe(train["expression"], train["velocity"], test["expression"], test["velocity"]),
        "content_velocity_ccc": velocity_probe(train["content"], train["velocity"], test["content"], test["velocity"]),
        "interpretation": "descriptive_held_out_linear_probes_not_causal",
    }
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
