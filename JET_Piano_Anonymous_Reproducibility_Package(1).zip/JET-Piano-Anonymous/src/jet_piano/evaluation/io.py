"""Reference-event readers for MAESTRO MIDI and MusicNet interval labels."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import pretty_midi


def maestro_reference(path: str | Path) -> pd.DataFrame:
    midi = pretty_midi.PrettyMIDI(str(path))
    pedal_intervals = []
    changes = sorted(
        (control.time, control.value >= 64)
        for instrument in midi.instruments
        for control in instrument.control_changes
        if control.number == 64
    )
    start = None
    for time, down in changes:
        if down and start is None: start = time
        elif not down and start is not None:
            pedal_intervals.append((start, time)); start = None
    if start is not None: pedal_intervals.append((start, midi.get_end_time()))
    rows = []
    for instrument in midi.instruments:
        if instrument.is_drum: continue
        for note in instrument.notes:
            sounding = note.end
            for pedal_start, pedal_end in pedal_intervals:
                if pedal_start <= note.end <= pedal_end:
                    sounding = pedal_end; break
            rows.append({"pitch": note.pitch, "onset_s": note.start, "key_release_s": note.end, "sounding_offset_s": sounding, "velocity": note.velocity})
    return pd.DataFrame(rows).sort_values(["onset_s", "pitch"]).reset_index(drop=True)


def musicnet_reference(path: str | Path, duration_s: float, source_sample_rate: int = 44100) -> pd.DataFrame:
    labels = pd.read_csv(path)
    columns = {column.lower(): column for column in labels.columns}
    pitch_col = next((columns[key] for key in ("note", "pitch", "midi") if key in columns), None)
    start_col = next((columns[key] for key in ("start_time", "onset", "start") if key in columns), None)
    end_col = next((columns[key] for key in ("end_time", "offset", "end") if key in columns), None)
    if None in (pitch_col, start_col, end_col):
        raise ValueError(f"Unrecognized MusicNet label schema in {path}")
    start = labels[start_col].to_numpy(float); end = labels[end_col].to_numpy(float)
    if max(np.max(start, initial=0), np.max(end, initial=0)) > duration_s * 10:
        start = start / source_sample_rate; end = end / source_sample_rate
    return pd.DataFrame({"pitch": labels[pitch_col].astype(int), "onset_s": start, "key_release_s": end, "sounding_offset_s": end}).sort_values(["onset_s", "pitch"]).reset_index(drop=True)
