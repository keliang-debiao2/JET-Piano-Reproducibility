"""Performance-level loading, target construction, and post-split segmentation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pretty_midi
import soundfile as sf
import torch
from scipy.signal import resample_poly
from torch.utils.data import Dataset


@dataclass(frozen=True)
class Segment:
    recording_id: str
    work_id: str
    start_sample: int
    end_sample: int
    valid_start_sample: int
    valid_end_sample: int


def read_audio(path: Path, sample_rate: int) -> np.ndarray:
    audio, source_rate = sf.read(path, always_2d=True, dtype="float32")
    mono = audio.mean(axis=1)
    if source_rate != sample_rate:
        gcd = np.gcd(source_rate, sample_rate)
        mono = resample_poly(mono, sample_rate // gcd, source_rate // gcd).astype(np.float32)
    return mono


def build_segments(
    recording_id: str,
    work_id: str,
    total_samples: int,
    sample_rate: int,
    center_seconds: float,
    context_seconds: float,
    overlap: float,
) -> list[Segment]:
    center = int(round(center_seconds * sample_rate))
    context = int(round(context_seconds * sample_rate))
    stride = max(1, int(round(center * (1.0 - overlap))))
    starts = list(range(0, max(total_samples, 1), stride))
    segments = []
    for valid_start in starts:
        valid_end = min(valid_start + center, total_samples)
        start = max(0, valid_start - context)
        end = min(total_samples, valid_end + context)
        segments.append(Segment(recording_id, work_id, start, end, valid_start, valid_end))
        if valid_end == total_samples:
            break
    return segments


def midi_targets(
    midi_path: Path,
    start_seconds: float,
    end_seconds: float,
    hop_seconds: float,
    midi_min: int = 21,
    midi_max: int = 108,
) -> dict[str, np.ndarray]:
    midi = pretty_midi.PrettyMIDI(str(midi_path))
    # torch.stft(center=True) yields floor(samples / hop) + 1 frames.
    frames = int(np.floor((end_seconds - start_seconds) / hop_seconds)) + 1
    pitches = midi_max - midi_min + 1
    onset = np.zeros((frames, pitches), dtype=np.float32)
    states = np.zeros((frames, pitches), dtype=np.int64)
    pedal = np.zeros(frames, dtype=np.float32)
    notes: list[tuple[float, float, float, int, int]] = []
    cc64 = []
    for instrument in midi.instruments:
        if instrument.is_drum:
            continue
        for control in instrument.control_changes:
            if control.number == 64:
                cc64.append((control.time, control.value >= 64))
    cc64.sort()
    pedal_intervals = []
    active = None
    for time, down in cc64:
        if down and active is None:
            active = time
        elif not down and active is not None:
            pedal_intervals.append((active, time))
            active = None
    if active is not None:
        pedal_intervals.append((active, midi.get_end_time()))
    for p_start, p_end in pedal_intervals:
        left = max(0, int(np.floor((p_start - start_seconds) / hop_seconds)))
        right = min(frames, int(np.ceil((p_end - start_seconds) / hop_seconds)))
        pedal[left:right] = 1.0
    for instrument in midi.instruments:
        if instrument.is_drum:
            continue
        for note in instrument.notes:
            # Each note is supervised in the earliest overlapping segment whose
            # contextual input contains its true onset.  A note already active
            # before the available left context cannot be assigned a valid
            # Off-to-Key transition inside this segment and is therefore not
            # duplicated as an artificial boundary onset.
            if not midi_min <= note.pitch <= midi_max or note.start < start_seconds or note.start >= end_seconds:
                continue
            sounding_end = note.end
            for p_start, p_end in pedal_intervals:
                if p_start <= note.end <= p_end:
                    sounding_end = p_end
                    break
            pitch = note.pitch - midi_min
            onset_frame_raw = int(round((note.start - start_seconds) / hop_seconds))
            key_frame = int(round((note.end - start_seconds) / hop_seconds))
            snd_frame = int(round((sounding_end - start_seconds) / hop_seconds))
            state_start = int(np.clip(onset_frame_raw, 0, frames - 1))
            key_frame = int(np.clip(key_frame, state_start + 1, frames))
            snd_frame = int(np.clip(snd_frame, key_frame, frames))
            if 0 <= onset_frame_raw < frames:
                onset[onset_frame_raw, pitch] = 1.0
            states[state_start:key_frame, pitch] = 1
            states[key_frame:snd_frame, pitch] = 2
            if start_seconds <= note.start < end_seconds:
                notes.append(
                    (
                        note.start - start_seconds,
                        note.end - start_seconds,
                        sounding_end - start_seconds,
                        note.pitch,
                        note.velocity,
                    )
                )
    notes.sort(key=lambda item: (item[0], item[3]))
    events = np.asarray(notes, dtype=np.float32).reshape(-1, 5)
    return {"onset": onset, "states": states, "pedal": pedal, "events": events}


class MaestroSegmentDataset(Dataset):
    """Segments one split only after the manifest has an outer-fold assignment."""

    def __init__(
        self,
        manifest: pd.DataFrame,
        root: str | Path,
        sample_rate: int = 22050,
        hop_length: int = 256,
        segment_seconds: float = 20.0,
        context_seconds: float = 2.0,
        overlap: float = 0.5,
    ) -> None:
        self.manifest = manifest.reset_index(drop=True)
        self.root = Path(root)
        self.sample_rate = sample_rate
        self.hop_length = hop_length
        self.segments: list[tuple[int, Segment]] = []
        for index, row in self.manifest.iterrows():
            total = int(round(float(row["duration_s"]) * sample_rate))
            for segment in build_segments(
                row["recording_id"], row["work_id"], total, sample_rate,
                segment_seconds, context_seconds, overlap,
            ):
                self.segments.append((index, segment))

    def __len__(self) -> int:
        return len(self.segments)

    def __getitem__(self, index: int) -> dict[str, Any]:
        row_index, segment = self.segments[index]
        row = self.manifest.iloc[row_index]
        audio = read_audio(self.root / row["audio_path"], self.sample_rate)
        waveform = audio[segment.start_sample : segment.end_sample]
        start_seconds = segment.start_sample / self.sample_rate
        end_seconds = segment.end_sample / self.sample_rate
        targets = midi_targets(
            self.root / row["label_path"], start_seconds, end_seconds,
            self.hop_length / self.sample_rate,
        )
        return {
            "waveform": torch.from_numpy(waveform),
            "targets": {key: torch.from_numpy(value) for key, value in targets.items()},
            "recording_id": row["recording_id"],
            "work_id": row["work_id"],
            "year": int(row["year"]),
            "pitch_density": float(row["pitch_density"]),
            "segment": segment,
        }


def collate_segments(batch: list[dict[str, Any]]) -> dict[str, Any]:
    max_samples = max(item["waveform"].numel() for item in batch)
    waveforms = torch.zeros(len(batch), max_samples, dtype=torch.float32)
    lengths = torch.zeros(len(batch), dtype=torch.long)
    for i, item in enumerate(batch):
        length = item["waveform"].numel()
        waveforms[i, :length] = item["waveform"]
        lengths[i] = length
    return {
        "waveform": waveforms,
        "lengths": lengths,
        "items": batch,
    }
