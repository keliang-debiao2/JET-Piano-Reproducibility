"""Dataset manifest construction without redistributing source data."""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import pretty_midi
import soundfile as sf

from jet_piano.utils import sha256_file, stable_id

_PUNCT = re.compile(r"[^a-z0-9]+")
_MOVEMENT = re.compile(r"\b(?:movement|mov|mvt|no|nr)\s*([0-9ivx]+)\b")


def normalize_text(value: object) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = text.encode("ascii", "ignore").decode("ascii").lower()
    text = _MOVEMENT.sub(r"movement \1", text)
    return _PUNCT.sub(" ", text).strip()


def _audio_duration(path: Path) -> float:
    info = sf.info(path)
    return float(info.frames / info.samplerate)


def _midi_stats(path: Path) -> tuple[int, float, int, int]:
    midi = pretty_midi.PrettyMIDI(str(path))
    notes = [note for instrument in midi.instruments if not instrument.is_drum for note in instrument.notes]
    duration = max((note.end for note in notes), default=0.0)
    pitches = [note.pitch for note in notes]
    return len(notes), duration, min(pitches, default=-1), max(pitches, default=-1)


def build_maestro_manifest(root: str | Path, strict: bool = True) -> pd.DataFrame:
    root = Path(root).resolve()
    metadata_files = sorted(root.glob("maestro-v3.0.0*.csv")) or sorted(root.glob("*.csv"))
    if not metadata_files:
        raise FileNotFoundError(f"No MAESTRO metadata CSV found under {root}")
    source = pd.read_csv(metadata_files[0])
    rows = []
    for _, row in source.iterrows():
        audio_rel = Path(str(row["audio_filename"]))
        midi_rel = Path(str(row["midi_filename"]))
        audio = root / audio_rel
        midi = root / midi_rel
        if not audio.is_file() or not midi.is_file():
            if strict:
                raise FileNotFoundError(f"Missing pair: {audio_rel} / {midi_rel}")
            continue
        composer = str(row.get("canonical_composer", row.get("composer", "")))
        title = str(row.get("canonical_title", row.get("title", "")))
        composer_key = normalize_text(composer)
        work_key = normalize_text(title)
        note_count, midi_duration, pitch_min, pitch_max = _midi_stats(midi)
        audio_duration = _audio_duration(audio)
        if strict and (pitch_min < 21 or pitch_max > 108):
            raise ValueError(f"Out-of-range pitch in {midi_rel}: {pitch_min}-{pitch_max}")
        rows.append(
            {
                "recording_id": stable_id(str(audio_rel), prefix="maestro"),
                "audio_path": audio_rel.as_posix(),
                "label_path": midi_rel.as_posix(),
                "composer": composer,
                "title": title,
                "composer_normalized": composer_key,
                "work_normalized": work_key,
                "work_id": stable_id(composer_key, work_key, prefix="work"),
                "year": int(row.get("year", 0)),
                "duration_s": audio_duration,
                "midi_duration_s": midi_duration,
                "duration_difference_s": abs(audio_duration - midi_duration),
                "note_count": note_count,
                "pitch_density": note_count / max(audio_duration, 1e-9),
                "pitch_min": pitch_min,
                "pitch_max": pitch_max,
                "audio_sha256": sha256_file(audio),
                "label_sha256": sha256_file(midi),
            }
        )
    result = pd.DataFrame(rows).sort_values("recording_id").reset_index(drop=True)
    if strict and len(result) != 1276:
        raise ValueError(f"Expected 1,276 MAESTRO pairs, found {len(result)}")
    return result


def _find_musicnet_pairs(root: Path) -> Iterable[tuple[str, Path, Path]]:
    label_candidates = list(root.rglob("*.csv"))
    for label in sorted(label_candidates):
        stem = label.stem
        audio_candidates = list(root.rglob(f"{stem}.wav")) + list(root.rglob(f"{stem}.flac"))
        if audio_candidates:
            yield stem, audio_candidates[0], label


def build_musicnet_manifest(root: str | Path, strict: bool = True) -> pd.DataFrame:
    root = Path(root).resolve()
    metadata_path = next(iter(sorted(root.rglob("*metadata*.csv"))), None)
    metadata = pd.read_csv(metadata_path) if metadata_path else pd.DataFrame()
    if not metadata.empty:
        key_col = next((col for col in metadata.columns if col.lower() in {"id", "recording_id"}), None)
        if key_col is not None:
            metadata[key_col] = metadata[key_col].astype(str)
            metadata = metadata.set_index(key_col, drop=False)
    rows = []
    for stem, audio, label in _find_musicnet_pairs(root):
        labels = pd.read_csv(label)
        instrument_col = next((c for c in labels.columns if c.lower() in {"instrument", "instrument_id"}), None)
        if instrument_col is not None and not (labels[instrument_col].astype(int) == 1).all():
            continue
        pitch_col = next((c for c in labels.columns if c.lower() in {"note", "pitch", "midi"}), None)
        if pitch_col is None:
            continue
        meta = metadata.loc[stem] if not metadata.empty and stem in metadata.index else {}
        composer = str(meta.get("composer", "unknown")) if hasattr(meta, "get") else "unknown"
        catalogue = str(
            meta.get("catalog_name", meta.get("catalogue", meta.get("title", stem)))
        ) if hasattr(meta, "get") else stem
        composer_key = normalize_text(composer)
        work_key = normalize_text(catalogue)
        audio_rel = audio.relative_to(root)
        label_rel = label.relative_to(root)
        rows.append(
            {
                "recording_id": stable_id(stem, prefix="musicnet"),
                "source_recording_id": stem,
                "audio_path": audio_rel.as_posix(),
                "label_path": label_rel.as_posix(),
                "composer": composer,
                "catalogue": catalogue,
                "composer_normalized": composer_key,
                "work_normalized": work_key,
                "work_cluster_id": stable_id(composer_key, work_key, prefix="mnwork"),
                "duration_s": _audio_duration(audio),
                "pitch_min": int(labels[pitch_col].min()),
                "pitch_max": int(labels[pitch_col].max()),
                "note_count": int(len(labels)),
                "audio_sha256": sha256_file(audio),
                "label_sha256": sha256_file(label),
            }
        )
    result = pd.DataFrame(rows).sort_values("recording_id").reset_index(drop=True)
    if strict and len(result) != 156:
        raise ValueError(f"Expected 156 MusicNet solo-piano recordings, found {len(result)}")
    clusters = result["work_cluster_id"].nunique() if not result.empty else 0
    if strict and clusters != 62:
        raise ValueError(f"Expected 62 MusicNet work clusters, found {clusters}")
    return result
