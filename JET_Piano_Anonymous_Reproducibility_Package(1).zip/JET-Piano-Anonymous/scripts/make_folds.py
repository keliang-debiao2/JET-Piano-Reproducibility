#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from jet_piano.data.folds import assign_grouped_folds, audit_fold_leakage
from jet_piano.utils import sha256_file, write_json


def calibration_groups(frame: pd.DataFrame, fraction: float, seed: int) -> set[str]:
    groups = frame.groupby("work_id").agg(duration_s=("duration_s", "sum"), n=("recording_id", "size"))
    rng = np.random.default_rng(seed)
    order = groups.index.to_numpy(); rng.shuffle(order)
    target = max(1, int(round(len(frame) * fraction))); chosen, count = set(), 0
    for group in order:
        chosen.add(group); count += int(groups.loc[group, "n"])
        if count >= target: break
    return chosen


def main() -> None:
    parser = argparse.ArgumentParser(description="Create nested group-aware folds")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--n-folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20261031)
    parser.add_argument("--calibration-fraction", type=float, default=0.10)
    args = parser.parse_args()
    frame = pd.read_csv(args.manifest)
    frame["outer_fold"] = assign_grouped_folds(frame, n_folds=args.n_folds, seed=args.seed)
    audit_fold_leakage(frame)
    for outer in range(1, args.n_folds + 1):
        development = frame[frame.outer_fold != outer].copy()
        calibration = calibration_groups(development, args.calibration_fraction, args.seed + outer)
        frame[f"is_calibration_o{outer}"] = frame.work_id.isin(calibration) & frame.outer_fold.ne(outer)
        inner_source = development[~development.work_id.isin(calibration)].copy()
        inner_source["inner"] = assign_grouped_folds(inner_source, n_folds=3, seed=args.seed + 100 + outer)
        mapping = inner_source.groupby("work_id").inner.first().to_dict()
        frame[f"inner_fold_o{outer}"] = frame.work_id.map(mapping).fillna(0).astype(int)
    target = Path(args.out); target.parent.mkdir(parents=True, exist_ok=True); frame.to_csv(target, index=False)
    sizes = frame.groupby("outer_fold").size().to_dict()
    groups = frame.groupby("outer_fold").work_id.nunique().to_dict()
    write_json(target.with_suffix(".audit.json"), {"fold_sizes": sizes, "fold_work_groups": groups, "manifest_sha256": sha256_file(target)})
    print({"fold_sizes": sizes, "fold_work_groups": groups})


if __name__ == "__main__":
    main()
