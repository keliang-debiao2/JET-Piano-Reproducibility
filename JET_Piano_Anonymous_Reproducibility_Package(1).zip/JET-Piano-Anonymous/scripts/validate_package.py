#!/usr/bin/env python3
from __future__ import annotations

import argparse
import compileall
import json
import re
from pathlib import Path

import pandas as pd
import yaml


REQUIRED = [
    "README.md", "LICENSE", "pyproject.toml", "environment.yml", "configs/base.yaml",
    "src/jet_piano/models/jet_piano.py", "src/jet_piano/models/paces.py",
    "scripts/train_fold.py", "scripts/evaluate_internal.py", "scripts/evaluate_external.py",
    "logs/simulated_reference/README.md",
]


def validate_reference_logs(root: Path) -> list[str]:
    errors = []
    directory = root / "logs/simulated_reference"
    for path in directory.glob("*.csv"):
        frame = pd.read_csv(path)
        if "evidence_class" not in frame or not frame.evidence_class.eq(
            "SIMULATED_REFERENCE_NOT_EMPIRICAL"
        ).all():
            errors.append(f"{path.name} lacks the mandatory simulation marker")
    folds = pd.read_csv(directory / "internal_five_fold.csv")
    expected = {"onset_f1": 98.7, "onset_offset_f1": 94.3, "velocity_aware_f1": 93.3}
    for column, target in expected.items():
        observed = round(float(folds[column].mean()), 1)
        if observed != target: errors.append(f"{column} mean {observed} != {target}")
    external = pd.read_csv(directory / "external_validation.csv")
    jet = external[external.model == "JET-Piano"].iloc[0]
    if round(float(jet.onset_f1), 1) != 85.6: errors.append("External JET-Piano onset F1 mismatch")
    ablation = pd.read_csv(directory / "ablations.csv")
    full = ablation[ablation.variant == "Full JET-Piano"].iloc[0]
    if round(float(full.onset_mean), 1) != expected["onset_f1"]:
        errors.append("Full ablation onset score disagrees with internal summary")
    if round(float(full.musicnet_onset_f1), 1) != round(float(jet.onset_f1), 1):
        errors.append("Full ablation external score disagrees with external table")
    baselines = pd.read_csv(directory / "baselines_common_fold.csv").set_index("model")
    statistics = pd.read_csv(directory / "paired_statistics.csv")
    internal_onset = statistics[(statistics.dataset == "MAESTRO") & (statistics.endpoint == "onset_f1")].iloc[0]
    calculated = expected["onset_f1"] - float(baselines.loc["TransKun v2", "onset_mean"])
    if round(float(internal_onset.mean_difference), 1) != round(calculated, 1):
        errors.append("Paired internal onset difference disagrees with baseline table")
    external_onset = statistics[(statistics.dataset == "MusicNet") & (statistics.endpoint == "onset_f1")].iloc[0]
    external_delta = float(jet.onset_f1) - float(external[external.model == "TransKun v2"].iloc[0].onset_f1)
    if round(float(external_onset.mean_difference), 1) != round(external_delta, 1):
        errors.append("Paired external onset difference disagrees with external table")
    calibration = json.loads((directory / "calibration_summary.json").read_text())
    if calibration.get("evidence_class") != "SIMULATED_REFERENCE_NOT_EMPIRICAL": errors.append("Calibration log lacks simulation marker")
    return errors


def anonymity_findings(root: Path) -> list[str]:
    patterns = {
        "email": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
        "home_path": re.compile(r"(?:/home/|/Users/|[A-Za-z]:\\\\Users\\\\)"),
        "token": re.compile(r"(?:api[_-]?key|access[_-]?token|secret)\s*[:=]\s*[^\s]+", re.I),
    }
    findings = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".py", ".md", ".yaml", ".yml", ".toml", ".json", ".csv", ".txt", ".cff"}: continue
        # The validator contains the detection expressions themselves.
        if path.resolve() == Path(__file__).resolve():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for name, pattern in patterns.items():
            if pattern.search(text): findings.append(f"{name}: {path.relative_to(root)}")
    return findings


def validate_manifests(directory: Path) -> list[str]:
    errors = []
    maestro = directory / "maestro_folds.csv"; musicnet = directory / "musicnet_solo_piano_manifest.csv"
    if maestro.exists():
        frame = pd.read_csv(maestro)
        if len(frame) != 1276: errors.append(f"MAESTRO count is {len(frame)}, expected 1276")
        for column in ("work_id", "audio_sha256", "label_sha256"):
            if column in frame:
                crossing = frame.groupby(column).outer_fold.nunique().gt(1).sum()
                if crossing: errors.append(f"{crossing} {column} values cross outer folds")
    if musicnet.exists():
        frame = pd.read_csv(musicnet)
        if len(frame) != 156: errors.append(f"MusicNet count is {len(frame)}, expected 156")
        if frame.work_cluster_id.nunique() != 62: errors.append("MusicNet cluster count is not 62")
    return errors


def main() -> None:
    parser = argparse.ArgumentParser(description="Static and provenance validation for anonymous release")
    parser.add_argument("--strict-anonymous", action="store_true")
    parser.add_argument("--manifests", default=None)
    parser.add_argument("--output", default=None)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    errors = [f"Missing required file: {path}" for path in REQUIRED if not (root / path).is_file()]
    config = yaml.safe_load((root / "configs/base.yaml").read_text())
    if config["data"]["sample_rate"] != 22050 or config["data"]["hop_length"] != 256: errors.append("Feature timing configuration does not match the manuscript")
    if config["model"]["dtat"]["layers"] != 6 or config["model"]["dtat"]["heads"] != 8: errors.append("DTAT configuration mismatch")
    if config["model"]["paces"]["duration_lookup_frames"] != 1024: errors.append("PACES duration lookup mismatch")
    if config["efficiency"]["warmup_repetitions"] != 100 or config["efficiency"]["timed_repetitions"] != 1000:
        errors.append("Efficiency repetition counts do not match the manuscript")
    errors.extend(validate_reference_logs(root))
    if args.strict_anonymous: errors.extend(anonymity_findings(root))
    if args.manifests: errors.extend(validate_manifests(Path(args.manifests)))
    compiled = compileall.compile_dir(root / "src", quiet=1) and compileall.compile_dir(root / "scripts", quiet=1)
    if not compiled: errors.append("Python bytecode compilation failed")
    result = {"status": "PASS" if not errors else "FAIL", "evidence_class": "PACKAGE_STRUCTURE_VALIDATION", "errors": errors, "checks": {"required_files": True, "configuration": True, "simulated_reference_consistency": True, "python_compilation": compiled, "strict_anonymous": args.strict_anonymous}}
    if args.output: Path(args.output).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if errors: raise SystemExit(1)


if __name__ == "__main__":
    main()
