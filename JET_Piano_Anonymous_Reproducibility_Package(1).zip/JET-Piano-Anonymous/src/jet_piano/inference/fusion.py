"""Window-to-performance reconstruction performed before nonlinear decisions."""

from __future__ import annotations

import torch


def hann_valid_weights(length: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    if length <= 1:
        return torch.ones(length, device=device, dtype=dtype)
    weights = torch.hann_window(length, periodic=False, device=device, dtype=dtype)
    return weights.clamp_min(1e-4)


def hann_fuse(
    window_outputs: list[torch.Tensor],
    valid_ranges: list[tuple[int, int]],
    total_frames: int,
) -> torch.Tensor:
    """Fuse aligned valid centers; sigmoid/softmax/decoding must occur afterward."""
    if len(window_outputs) != len(valid_ranges) or not window_outputs:
        raise ValueError("Window outputs and valid ranges must have the same non-zero length")
    trailing = window_outputs[0].shape[1:]
    fused = window_outputs[0].new_zeros((total_frames, *trailing))
    denominator = window_outputs[0].new_zeros((total_frames, *([1] * len(trailing))))
    for output, (start, end) in zip(window_outputs, valid_ranges):
        length = end - start
        if output.shape[0] != length:
            raise ValueError(f"Output length {output.shape[0]} does not match valid range {start}:{end}")
        weight = hann_valid_weights(length, output.device, output.dtype)
        expanded = weight.view(length, *([1] * len(trailing)))
        fused[start:end] += output * expanded
        denominator[start:end] += expanded
    if (denominator == 0).any():
        raise ValueError("At least one performance frame received no valid window contribution")
    return fused / denominator
