"""Differentiable log-Mel and Bark-loudness feature extraction."""

from __future__ import annotations

import math

import torch
from torch import nn
from torchaudio.functional import melscale_fbanks


def hz_to_bark(freq: torch.Tensor) -> torch.Tensor:
    return 6.0 * torch.asinh(freq / 600.0)


def bark_filterbank(
    n_freqs: int,
    n_bands: int,
    sample_rate: int,
    n_fft: int,
    f_min: float,
    f_max: float,
) -> torch.Tensor:
    freqs = torch.linspace(0.0, sample_rate / 2, n_freqs)
    bark = hz_to_bark(freqs)
    lo = hz_to_bark(torch.tensor(float(f_min)))
    hi = hz_to_bark(torch.tensor(float(f_max)))
    centers = torch.linspace(lo, hi, n_bands + 2)
    banks = []
    for index in range(n_bands):
        left, center, right = centers[index : index + 3]
        rising = (bark - left) / (center - left).clamp_min(1e-8)
        falling = (right - bark) / (right - center).clamp_min(1e-8)
        banks.append(torch.minimum(rising, falling).clamp(0.0, 1.0))
    return torch.stack(banks, dim=1)


class AcousticFeatureExtractor(nn.Module):
    """Map mono waveform batches `[B, samples]` to `[B, frames, 253]`."""

    def __init__(
        self,
        sample_rate: int = 22050,
        n_fft: int = 2048,
        hop_length: int = 256,
        n_mels: int = 229,
        n_bark: int = 24,
        f_min: float = 27.5,
        f_max: float | None = None,
    ) -> None:
        super().__init__()
        self.sample_rate = sample_rate
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.f_max = float(f_max or sample_rate / 2)
        self.register_buffer("window", torch.hann_window(n_fft), persistent=False)
        mel = melscale_fbanks(
            n_freqs=n_fft // 2 + 1,
            f_min=f_min,
            f_max=self.f_max,
            n_mels=n_mels,
            sample_rate=sample_rate,
            norm="slaney",
            mel_scale="slaney",
        )
        bark = bark_filterbank(
            n_freqs=n_fft // 2 + 1,
            n_bands=n_bark,
            sample_rate=sample_rate,
            n_fft=n_fft,
            f_min=f_min,
            f_max=self.f_max,
        )
        self.register_buffer("mel_filter", mel, persistent=False)
        self.register_buffer("bark_filter", bark, persistent=False)

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        spectrum = torch.stft(
            waveform,
            n_fft=self.n_fft,
            hop_length=self.hop_length,
            win_length=self.n_fft,
            window=self.window.to(waveform),
            center=True,
            return_complex=True,
        )
        power = spectrum.abs().square().transpose(1, 2)
        mel = torch.matmul(power, self.mel_filter.to(power)).clamp_min(1e-10).log()
        bark_energy = torch.matmul(power, self.bark_filter.to(power)).clamp_min(1e-10)
        bark_specific_loudness = torch.pow(bark_energy, 0.23)
        bark_specific_loudness = torch.log1p(bark_specific_loudness)
        return torch.cat([mel, bark_specific_loudness], dim=-1)

    @property
    def frame_seconds(self) -> float:
        return self.hop_length / self.sample_rate
