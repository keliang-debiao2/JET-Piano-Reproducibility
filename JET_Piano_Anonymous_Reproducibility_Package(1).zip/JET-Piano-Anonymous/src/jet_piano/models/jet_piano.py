"""End-to-end JET-Piano model and inference-facing outputs."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from jet_piano.data.features import AcousticFeatureExtractor
from jet_piano.models.cerd import CERD
from jet_piano.models.crnn import CRNNBackbone
from jet_piano.models.dtat import DualTimescaleAcousticTokenizer
from jet_piano.models.front_end import ConvStem
from jet_piano.models.paces import PACES
from jet_piano.models.pooling import OnsetGuidedEventPool


class JETPiano(nn.Module):
    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__()
        data = config["data"]
        model = config["model"]
        latent = int(model["latent_dim"])
        self.midi_min = int(data["midi_min"])
        self.pitches = int(data["midi_max"] - data["midi_min"] + 1)
        self.features = AcousticFeatureExtractor(
            sample_rate=int(data["sample_rate"]),
            n_fft=int(data["n_fft"]),
            hop_length=int(data["hop_length"]),
            n_mels=int(data["n_mels"]),
            n_bark=int(data["n_bark"]),
            f_min=float(data["f_min"]),
            f_max=float(data["f_max"]),
        )
        feature_dim = int(data["n_mels"] + data["n_bark"])
        self.register_buffer("feature_median", torch.zeros(feature_dim))
        self.register_buffer("feature_iqr", torch.ones(feature_dim))
        self.stem = ConvStem(
            input_dim=int(data["n_mels"] + data["n_bark"]),
            latent_dim=latent,
            kernel_sizes=tuple(model["conv_kernel_sizes"]),
            groups=int(model["conv_groups"]),
        )
        dtat = model["dtat"]
        if model.get("backbone", "dtat") == "crnn":
            self.dtat = CRNNBackbone(
                dim=latent,
                hidden=int(model.get("crnn_hidden", 512)),
                layers=int(model.get("crnn_layers", 3)),
                window_frames=int(dtat["local_window_frames"]),
                dropout=float(dtat["dropout"]),
            )
        else:
            self.dtat = DualTimescaleAcousticTokenizer(
                dim=latent,
                layers=int(dtat["layers"]),
                heads=int(dtat["heads"]),
                feedforward_dim=int(dtat["feedforward_dim"]),
                window_frames=int(dtat["local_window_frames"]),
                dropout=float(dtat["dropout"]),
                disable_summary_exchange=bool(dtat.get("disable_summary_exchange", False)),
            )
        pooling = model["onset_pooling"]
        self.pooling = OnsetGuidedEventPool(
            dim=latent,
            pitches=self.pitches,
            width_frames=float(pooling["gaussian_width_frames"]),
            neighborhood_frames=int(pooling["neighborhood_frames"]),
        )
        paces = model["paces"]
        self.paces = PACES(
            dim=latent,
            pitches=self.pitches,
            duration_frames=int(paces["duration_lookup_frames"]),
        )
        cerd = model["cerd"]
        self.content_dim = int(cerd["content_dim"])
        self.expression_dim = int(cerd["expression_dim"])
        self.cerd = CERD(
            event_dim=latent,
            summary_dim=latent,
            pitches=self.pitches,
            pitch_embedding_dim=int(cerd["pitch_embedding_dim"]),
            time_embedding_dim=int(cerd["time_embedding_dim"]),
            content_dim=int(cerd["content_dim"]),
            expression_dim=int(cerd["expression_dim"]),
            hidden_dim=int(cerd["hidden_dim"]),
            attributes=len(cerd["attributes"]),
            shared_representation=bool(cerd.get("shared_representation", False)),
        )
        self.uniform_pooling = bool(pooling.get("uniform_pooling", False))
        self.independent_frame_decoder = bool(paces.get("independent_frame_decoder", False))

    def encode(self, waveform: torch.Tensor, feature_transform=None) -> dict[str, torch.Tensor]:
        acoustic = self.features(waveform)
        acoustic = (acoustic - self.feature_median) / self.feature_iqr.clamp_min(1e-6)
        if feature_transform is not None:
            acoustic = feature_transform(acoustic)
        stem = self.stem(acoustic)
        fine, summary, context = self.dtat(stem)
        onset_logits = self.pooling.forward_logits(fine)
        unary, pedal_logits = self.paces.forward_scores(fine)
        return {
            "acoustic": acoustic,
            "fine": fine,
            "summary": summary,
            "summary_context": context,
            "onset_logits": onset_logits,
            "unary_logits": unary,
            "pedal_logits": pedal_logits,
        }

    @torch.no_grad()
    def set_feature_normalization(self, median: torch.Tensor, iqr: torch.Tensor) -> None:
        if median.shape != self.feature_median.shape or iqr.shape != self.feature_iqr.shape:
            raise ValueError("Feature-normalization vectors have an incompatible shape")
        self.feature_median.copy_(median.to(self.feature_median))
        self.feature_iqr.copy_(iqr.to(self.feature_iqr).clamp_min(1e-6))

    def forward(
        self,
        waveform: torch.Tensor,
        candidate_sets: list[torch.Tensor] | None = None,
        onset_threshold: float = 0.45,
    ) -> dict[str, torch.Tensor | list[torch.Tensor]]:
        outputs = self.encode(waveform)
        return self.forward_from_encoded(outputs, candidate_sets, onset_threshold)

    def forward_from_encoded(
        self,
        outputs: dict[str, torch.Tensor],
        candidate_sets: list[torch.Tensor] | None = None,
        onset_threshold: float = 0.45,
    ) -> dict[str, torch.Tensor | list[torch.Tensor]]:
        if candidate_sets is None:
            candidate_sets = [
                self.pooling.suppress_same_pitch(candidates, tolerance_frames=4)
                for candidates in self.pooling.select_candidates(outputs["onset_logits"], onset_threshold)
            ]
        event, batch, frame, pitch = self.pooling.pool(
            outputs["fine"], outputs["onset_logits"], candidate_sets, uniform=self.uniform_pooling
        )
        if event.shape[0]:
            summary_context = outputs["summary_context"][batch, frame]
            outputs.update(self.cerd(event, summary_context, frame, pitch))
        else:
            attributes = len(self.cerd.attribute_heads)
            outputs.update(
                {
                    "content": event.new_zeros((0, self.content_dim)),
                    "expression": event.new_zeros((0, self.expression_dim)),
                    "attribute_mean": event.new_zeros((0, attributes)),
                    "attribute_log_variance": event.new_zeros((0, attributes)),
                }
            )
        outputs.update(
            {
                "candidate_sets": candidate_sets,
                "event_batch": batch,
                "event_frame": frame,
                "event_pitch": pitch,
            }
        )
        return outputs

    @torch.no_grad()
    def decode(
        self,
        outputs: dict[str, torch.Tensor | list[torch.Tensor]],
    ) -> list[Any]:
        onset_logits = outputs["onset_logits"]
        candidate_sets = outputs["candidate_sets"]
        candidate_mask = torch.zeros_like(onset_logits, dtype=torch.bool)
        for batch_index, candidates in enumerate(candidate_sets):
            if candidates.numel():
                candidate_mask[batch_index, candidates[:, 0].long(), candidates[:, 1].long()] = True
        if self.independent_frame_decoder:
            states = outputs["unary_logits"].argmax(dim=-1)
            return [states[index] for index in range(states.shape[0])]
        return self.paces.viterbi_decode(
            outputs["unary_logits"], onset_logits, candidate_mask, outputs["pedal_logits"]
        )

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)
