"""Loss terms corresponding to the manuscript objective."""

from __future__ import annotations

import torch
from torch.nn import functional as F

from jet_piano.models.cerd import cross_covariance_penalty


def onset_proposal_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    positive_weight: float = 8.0,
) -> torch.Tensor:
    weight = logits.new_tensor(positive_weight)
    return F.binary_cross_entropy_with_logits(logits, targets, pos_weight=weight)


def masked_gaussian_nll(
    mean: torch.Tensor,
    log_variance: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
    variance_min: float = 1e-4,
    variance_max: float = 10.0,
) -> torch.Tensor:
    variance = log_variance.exp().clamp(variance_min, variance_max)
    loss = 0.5 * ((target - mean).square() / variance + variance.log())
    selected = loss[mask]
    return selected.mean() if selected.numel() else loss.new_zeros(())


def jensen_shannon_from_logits(clean: torch.Tensor, augmented: torch.Tensor) -> torch.Tensor:
    p = clean.softmax(dim=-1)
    q = augmented.softmax(dim=-1)
    mixture = 0.5 * (p + q)
    kl_p = (p * (p.clamp_min(1e-8).log() - mixture.clamp_min(1e-8).log())).sum(dim=-1)
    kl_q = (q * (q.clamp_min(1e-8).log() - mixture.clamp_min(1e-8).log())).sum(dim=-1)
    return 0.5 * (kl_p + kl_q).mean()


def consistency_loss(
    clean: dict[str, torch.Tensor],
    augmented: dict[str, torch.Tensor],
    attribute_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    state = jensen_shannon_from_logits(clean["unary_logits"], augmented["unary_logits"])
    if clean["attribute_mean"].shape != augmented["attribute_mean"].shape:
        return state
    difference = (clean["attribute_mean"] - augmented["attribute_mean"]).abs()
    if attribute_mask is not None and attribute_mask.shape == difference.shape:
        difference = difference[attribute_mask]
    attribute = difference.mean() if difference.numel() else state.new_zeros(())
    return state + attribute


def orthogonality_loss(outputs: dict[str, torch.Tensor]) -> torch.Tensor:
    return cross_covariance_penalty(outputs["content"], outputs["expression"])
