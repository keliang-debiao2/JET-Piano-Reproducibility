# Baseline Reproduction and Import Contract

All comparators use the identical five normalized-work outer folds and the same
event-matching implementation as JET-Piano.  No outer-test labels may be used for
training, early stopping, threshold selection, temperature scaling, or checkpoint
selection.

The repository directly rescores event exports from logistic regression, random
forest, XGBoost, MLP, CRNN, and piano-specific neural systems through
`scripts/run_baselines.py`. Candidate-feature construction and model fitting must
be performed inside each outer-development partition; the scorer intentionally
does not infer or silently impose a training recipe on third-party systems.

For Onsets and Frames, high-resolution transcription, MT3, hFT-Transformer, and
TransKun v2, use each project's official implementation and license.  Export one
CSV per recording with this required schema:

```text
recording_id,onset_s,offset_s,pitch,velocity,confidence
```

`recording_id` must match `manifests/maestro_folds.csv`; onset and offset are in
seconds; pitch and velocity are MIDI units.  The adapter never accepts aggregate
metrics, so every comparator is rescored locally under the paper's 50-ms onset,
max(50 ms, 20% duration) offset, and 0.1 normalized-velocity tolerances.  Record
the upstream repository URL, commit, environment, fold checkpoint, and any
development-selected threshold in `baseline_provenance.json` beside the exported
events.

Example rescoring command:

```bash
python scripts/run_baselines.py \
  --manifest manifests/maestro_folds.csv \
  --maestro-root "$MAESTRO_ROOT" \
  --model-name "TransKun v2" \
  --events-root runs/baselines/transkun/events \
  --output runs/baselines/transkun
```

Published official-split values belong only in the contextual comparison table.
They must not be mixed with common-fold reproductions or used in paired tests.
