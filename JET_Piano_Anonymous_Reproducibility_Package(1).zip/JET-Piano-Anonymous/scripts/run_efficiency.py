#!/usr/bin/env python3
"""Benchmark a frozen checkpoint under the manuscript's 30-s protocol."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
import yaml

from jet_piano.evaluation.efficiency import benchmark
from jet_piano.inference.pipeline import load_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser(description="Parameter, FLOP, latency, and memory benchmark")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    run = Path(args.run_dir)
    config = yaml.safe_load((run / "resolved_config.yaml").read_text())
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model = load_checkpoint(run / "checkpoint_best.pt", config, device)
    seconds = int(config["efficiency"]["clip_seconds"])
    waveform = torch.zeros(1, seconds * int(config["data"]["sample_rate"]), device=device)

    def forward() -> object:
        return model(waveform, onset_threshold=1.1)

    with torch.profiler.profile(with_flops=True, record_shapes=False) as profile:
        forward()
    flops = sum(int(event.flops or 0) for event in profile.key_averages())
    timing = benchmark(
        forward,
        clip_seconds=seconds,
        warmup=int(config["efficiency"]["warmup_repetitions"]),
        repetitions=int(config["efficiency"]["timed_repetitions"]),
    )
    payload = {
        "parameters": model.parameter_count(),
        "flops": flops,
        "clip_seconds": seconds,
        "device": str(device),
        **timing,
    }
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
