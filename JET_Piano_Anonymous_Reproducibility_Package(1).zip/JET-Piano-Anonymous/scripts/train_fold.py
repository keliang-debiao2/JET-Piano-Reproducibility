#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import math

import pandas as pd
import torch
import yaml
from torch.utils.data import DataLoader

from jet_piano.config import load_config, merge_config
from jet_piano.data.datasets import MaestroSegmentDataset, collate_segments
from jet_piano.data.normalization import fit_robust_feature_statistics
from jet_piano.models import JETPiano
from jet_piano.training import GroupDRO, Trainer
from jet_piano.utils import git_revision, runtime_metadata, set_seed, sha256_file, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one leakage-controlled outer fold")
    parser.add_argument("--config", required=True)
    parser.add_argument("--fold-config", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--maestro-root", default=None)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    config = merge_config(load_config(args.config), {"fold_config": load_config(args.fold_config)})
    fold_cfg = config["fold_config"]; outer = int(fold_cfg["fold"]); seed = int(fold_cfg["seed"])
    for key in ("selected_lambda_orth", "selected_lambda_consistency"):
        if key in fold_cfg:
            config["training"][key] = float(fold_cfg[key])
    set_seed(seed); device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    manifest = pd.read_csv(args.manifest)
    train = manifest[(manifest.outer_fold != outer) & ~manifest[f"is_calibration_o{outer}"]].copy()
    root = args.maestro_root or __import__("os").environ.get("MAESTRO_ROOT")
    if not root: raise SystemExit("Set --maestro-root or MAESTRO_ROOT")
    dataset = MaestroSegmentDataset(train, root, sample_rate=config["data"]["sample_rate"], hop_length=config["data"]["hop_length"], segment_seconds=config["data"]["segment_seconds"], context_seconds=config["data"]["context_seconds"], overlap=config["data"]["overlap"])
    loader = DataLoader(dataset, batch_size=config["training"]["segments_per_gpu"], shuffle=True, num_workers=config["training"]["num_workers"], collate_fn=collate_segments, pin_memory=True)
    model = JETPiano(config).to(device)
    normalization_path = Path(args.output) / "feature_normalization.pt"
    if normalization_path.is_file():
        normalization = torch.load(normalization_path, map_location="cpu", weights_only=True)
        median, iqr = normalization["median"], normalization["iqr"]
    else:
        median, iqr = fit_robust_feature_statistics(model.features, train, root, device)
        normalization_path.parent.mkdir(parents=True, exist_ok=True)
        torch.save({"median": median, "iqr": iqr, "source": "outer_training_only"}, normalization_path)
    model.set_feature_normalization(median, iqr)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["training"]["learning_rate"], weight_decay=config["training"]["weight_decay"])
    accumulation = int(config["training"]["gradient_accumulation_steps"])
    optimizer_steps = max(1, math.ceil(len(loader) / accumulation) * config["training"]["epochs"])
    warmup_steps = max(1, int(round(optimizer_steps * config["training"]["warmup_fraction"])))

    def learning_rate_multiplier(step: int) -> float:
        if step < warmup_steps:
            return float(step + 1) / float(warmup_steps)
        progress = (step - warmup_steps) / max(1, optimizer_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * min(progress, 1.0)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, learning_rate_multiplier)
    years = sorted(train.year.unique()); year_map = {year: i for i, year in enumerate(years)}
    density_bins = pd.qcut(train.pitch_density.rank(method="first"), 3, labels=False).astype(int)
    density_map = dict(zip(train.recording_id, density_bins))
    group_dro = GroupDRO(len(years) * 3, config["training"]["group_dro_eta"], config["training"]["group_dro_ema"], device)
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    (output / "resolved_config.yaml").write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    write_json(output / "run_metadata.json", {**runtime_metadata(), "git_revision": git_revision(), "fold": outer, "seed": seed, "manifest_sha256": sha256_file(args.manifest), "train_recordings": len(train), "parameters": model.parameter_count()})
    trainer = Trainer(model, config, optimizer, scheduler, group_dro, output, device)
    best = float("inf"); stale = 0
    for epoch in range(1, config["training"]["epochs"] + 1):
        epoch_loss = 0.0
        for batch in loader:
            group_ids = torch.tensor([year_map[item["year"]] * 3 + density_map[item["recording_id"]] for item in batch["items"]], device=device, dtype=torch.long)
            values = trainer.train_step(batch, group_ids); epoch_loss += values["loss"]
        trainer.flush_accumulation()
        epoch_loss /= max(len(loader), 1)
        torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "group_dro": group_dro.state_dict(), "epoch": epoch, "config": config}, output / "checkpoint_last.pt")
        if epoch_loss < best:
            best, stale = epoch_loss, 0
            torch.save({"model": model.state_dict(), "epoch": epoch, "config": config}, output / "checkpoint_best.pt")
        else:
            stale += 1
            if stale >= config["training"]["early_stopping_patience"]: break
    write_json(output / "threshold.json", {"onset_threshold": fold_cfg["selected_onset_threshold"], "source": "inner_validation", "fold": outer})


if __name__ == "__main__":
    main()
