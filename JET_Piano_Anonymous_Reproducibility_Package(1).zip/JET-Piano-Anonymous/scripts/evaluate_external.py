#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml

from jet_piano.data.datasets import read_audio
from jet_piano.evaluation.io import musicnet_reference
from jet_piano.evaluation.metrics import recording_metrics
from jet_piano.inference.pipeline import (
    average_decoder_parameters,
    average_fused_outputs,
    decode_fused,
    encode_performance,
    load_checkpoint,
)
from jet_piano.utils import write_json


def cluster_interval(
    frame: pd.DataFrame,
    metric: str,
    resamples: int,
    seed: int = 20261031,
) -> tuple[float, float, float]:
    grouped = frame.groupby("work_cluster_id")[metric].mean().to_numpy(float)
    rng = np.random.default_rng(seed)
    index = rng.integers(0, len(grouped), size=(resamples, len(grouped)))
    boot = grouped[index].mean(axis=1)
    low, high = np.quantile(boot, [0.025, 0.975])
    return float(frame[metric].mean()), float(low), float(high)


def main() -> None:
    parser = argparse.ArgumentParser(description="Strict zero-shot five-checkpoint MusicNet validation")
    parser.add_argument("--runs", nargs=5, required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--musicnet-root", default=os.environ.get("MUSICNET_ROOT"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--zero-shot", action="store_true", required=True)
    args = parser.parse_args()
    if not args.musicnet_root:
        raise SystemExit("Set --musicnet-root or MUSICNET_ROOT")
    output = Path(args.output)
    (output / "predictions").mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    configs = [yaml.safe_load((Path(run) / "resolved_config.yaml").read_text()) for run in args.runs]
    models = [
        load_checkpoint(Path(run) / "checkpoint_best.pt", config, device)
        for run, config in zip(args.runs, configs)
    ]
    thresholds = [
        json.loads((Path(run) / "threshold.json").read_text())["onset_threshold"]
        for run in args.runs
    ]
    ensemble_model = average_decoder_parameters(models).to(device).eval()
    threshold = float(np.mean(thresholds))
    manifest = pd.read_csv(args.manifest)
    rows = []
    for _, row in manifest.iterrows():
        waveform = torch.from_numpy(
            read_audio(Path(args.musicnet_root) / row.audio_path, configs[0]["data"]["sample_rate"])
        )
        fused = average_fused_outputs(
            [
                encode_performance(model, waveform, config, device)
                for model, config in zip(models, configs)
            ]
        )
        estimate = decode_fused(ensemble_model, fused, threshold, include_velocity=False)
        estimate.insert(0, "recording_id", row.recording_id)
        estimate.insert(1, "work_cluster_id", row.work_cluster_id)
        estimate.to_parquet(output / "predictions" / f"{row.recording_id}.parquet", index=False)
        reference = musicnet_reference(
            Path(args.musicnet_root) / row.label_path, float(row.duration_s)
        )
        rows.append(
            {
                "recording_id": row.recording_id,
                "work_cluster_id": row.work_cluster_id,
                **recording_metrics(reference, estimate),
            }
        )
    metrics = pd.DataFrame(rows)
    metrics.to_csv(output / "recording_metrics.csv", index=False)
    summary = {}
    for metric in ("onset_f1", "onset_offset_f1", "duration_mae_s"):
        mean, low, high = cluster_interval(
            metrics, metric, configs[0]["validation"]["bootstrap_resamples"]
        )
        summary[metric] = {"mean": mean, "ci95_low": low, "ci95_high": high}
    payload = {
        "zero_shot": True,
        "recordings": len(metrics),
        "work_clusters": int(metrics.work_cluster_id.nunique()),
        "aggregation": configs[0]["external"]["aggregation"],
        "metrics": summary,
    }
    write_json(output / "summary.json", payload)
    print(payload)


if __name__ == "__main__":
    main()
