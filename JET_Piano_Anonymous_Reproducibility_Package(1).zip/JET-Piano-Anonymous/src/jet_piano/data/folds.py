"""Deterministic group-aware fold assignment and leakage audits."""

from __future__ import annotations

from collections import Counter
from typing import Iterable

import numpy as np
import pandas as pd


def _quantile_codes(values: pd.Series, bins: int = 5) -> pd.Series:
    ranked = values.rank(method="first")
    return pd.qcut(ranked, q=min(bins, len(ranked)), labels=False, duplicates="drop").astype(int)


def assign_grouped_folds(
    frame: pd.DataFrame,
    group_col: str = "work_id",
    n_folds: int = 5,
    seed: int = 20261031,
) -> pd.Series:
    """Greedily balance group size, year, duration, and pitch-density strata."""
    required = {group_col, "year", "duration_s", "pitch_density"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Missing fold columns: {sorted(missing)}")
    data = frame.copy()
    data["duration_bin"] = _quantile_codes(data["duration_s"])
    data["density_bin"] = _quantile_codes(data["pitch_density"])
    group_rows = []
    for group, rows in data.groupby(group_col, sort=False):
        strata = Counter(zip(rows["year"].astype(int), rows["duration_bin"], rows["density_bin"]))
        group_rows.append((group, len(rows), strata))
    rng = np.random.default_rng(seed)
    rng.shuffle(group_rows)
    group_rows.sort(key=lambda item: item[1], reverse=True)
    fold_sizes = np.zeros(n_folds, dtype=int)
    fold_strata = [Counter() for _ in range(n_folds)]
    total_target = len(data) / n_folds
    assignment: dict[str, int] = {}
    for group, size, strata in group_rows:
        costs = []
        for fold in range(n_folds):
            size_cost = ((fold_sizes[fold] + size - total_target) / max(total_target, 1)) ** 2
            stratum_cost = 0.0
            for key, count in strata.items():
                after = fold_strata[fold][key] + count
                target = sum(fs[key] for fs in fold_strata) / max(n_folds, 1) + count / n_folds
                stratum_cost += ((after - target) / max(target, 1.0)) ** 2
            costs.append(size_cost + 0.05 * stratum_cost)
        chosen = int(np.argmin(costs))
        assignment[group] = chosen + 1
        fold_sizes[chosen] += size
        fold_strata[chosen].update(strata)
    return frame[group_col].map(assignment).astype(int)


def audit_fold_leakage(
    frame: pd.DataFrame,
    fold_col: str = "outer_fold",
    group_cols: Iterable[str] = ("work_id", "audio_sha256", "label_sha256"),
) -> None:
    for column in group_cols:
        if column not in frame.columns:
            continue
        crossing = frame.groupby(column)[fold_col].nunique()
        crossing = crossing[crossing > 1]
        if len(crossing):
            raise ValueError(f"Leakage: {len(crossing)} {column} values cross {fold_col}")
    duplicates = frame["recording_id"].duplicated() if "recording_id" in frame else pd.Series(False)
    if bool(duplicates.any()):
        raise ValueError("Duplicate recording_id values detected")
