"""Pedal-aware constrained event-state semi-Markov decoder.

The implementation expands the Key-held and Pedal-sustained duration states up
to the manuscript's 1,024-frame lookup. A tail state then applies the learned
non-positive linear coefficient indefinitely. This preserves the untruncated
duration rule while keeping memory linear in the lookup length.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F

OFF, KEY, PEDAL = 0, 1, 2


@dataclass
class ViterbiResult:
    states: torch.Tensor
    score: torch.Tensor


class PACES(nn.Module):
    def __init__(self, dim: int = 256, pitches: int = 88, duration_frames: int = 1024) -> None:
        super().__init__()
        self.pitches = pitches
        self.duration_frames = duration_frames
        self.unary = nn.Linear(dim, pitches * 3)
        self.pedal_gate = nn.Linear(dim, 1)
        self.transition_bias = nn.ParameterDict(
            {
                "ok": nn.Parameter(torch.tensor(0.0)),
                "pk": nn.Parameter(torch.tensor(-0.5)),
                "kp": nn.Parameter(torch.tensor(0.0)),
                "ko": nn.Parameter(torch.tensor(0.0)),
                "po": nn.Parameter(torch.tensor(0.0)),
            }
        )
        self.duration_lookup = nn.Parameter(torch.zeros(2, duration_frames))
        self.duration_tail_raw = nn.Parameter(torch.full((2,), -4.0))

    def forward_scores(self, fine: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        batch, frames, _ = fine.shape
        unary = self.unary(fine).view(batch, frames, self.pitches, 3)
        pedal = self.pedal_gate(fine).squeeze(-1)
        return unary, pedal

    def duration_increments(self) -> tuple[torch.Tensor, torch.Tensor]:
        first = self.duration_lookup[:, :1]
        rest = self.duration_lookup[:, 1:] - self.duration_lookup[:, :-1]
        increments = torch.cat([first, rest], dim=1)
        tail = -F.softplus(self.duration_tail_raw)
        return increments, tail

    @staticmethod
    def _reduce(values: torch.Tensor, mode: str, dim: int) -> tuple[torch.Tensor, torch.Tensor | None]:
        if mode == "logsumexp":
            return torch.logsumexp(values, dim=dim), None
        if mode == "max":
            return torch.max(values, dim=dim)
        raise ValueError(f"Unknown reduction mode: {mode}")

    def _partition_one(
        self,
        unary: torch.Tensor,
        onset_logits: torch.Tensor,
        candidate_mask: torch.Tensor,
        pedal_logits: torch.Tensor,
    ) -> torch.Tensor:
        frames, pitches, _ = unary.shape
        duration, tail = self.duration_increments()
        neg_inf = torch.tensor(float("-inf"), device=unary.device, dtype=unary.dtype)
        o_prev = torch.zeros(pitches, device=unary.device, dtype=unary.dtype)
        k_prev = unary.new_full((pitches, self.duration_frames + 1), float("-inf"))
        p_prev = unary.new_full((pitches, self.duration_frames + 1), float("-inf"))
        for t in range(frames):
            log_down = F.logsigmoid(pedal_logits[t])
            log_up = F.logsigmoid(-pedal_logits[t])
            if t == 0:
                o_sources = o_prev[:, None]
            else:
                o_sources = torch.stack(
                    [
                        o_prev,
                        torch.logsumexp(k_prev, dim=1) + self.transition_bias["ko"] + log_up,
                        torch.logsumexp(p_prev, dim=1) + self.transition_bias["po"] + log_up,
                    ],
                    dim=1,
                )
            o_new = torch.logsumexp(o_sources, dim=1) + unary[t, :, OFF]

            gate = torch.where(candidate_mask[t], onset_logits[t], neg_inf)
            k_new = unary.new_full(k_prev.shape, float("-inf"))
            k_sources = torch.stack(
                [
                    o_prev + self.transition_bias["ok"] + gate,
                    torch.logsumexp(p_prev, dim=1) + self.transition_bias["pk"] + gate,
                ],
                dim=1,
            )
            k_new[:, 0] = torch.logsumexp(k_sources, dim=1) + unary[t, :, KEY] + duration[0, 0]
            k_new[:, 1 : self.duration_frames] = (
                k_prev[:, : self.duration_frames - 1]
                + unary[t, :, KEY, None]
                + duration[0, 1:][None, :]
            )
            k_new[:, -1] = torch.logsumexp(
                torch.stack(
                    [k_prev[:, self.duration_frames - 1], k_prev[:, -1]], dim=1
                ),
                dim=1,
            ) + unary[t, :, KEY] + tail[0]

            p_new = unary.new_full(p_prev.shape, float("-inf"))
            p_new[:, 0] = (
                torch.logsumexp(k_prev, dim=1)
                + self.transition_bias["kp"]
                + log_down
                + unary[t, :, PEDAL]
                + duration[1, 0]
            )
            p_new[:, 1 : self.duration_frames] = (
                p_prev[:, : self.duration_frames - 1]
                + unary[t, :, PEDAL, None]
                + duration[1, 1:][None, :]
            )
            p_new[:, -1] = torch.logsumexp(
                torch.stack(
                    [p_prev[:, self.duration_frames - 1], p_prev[:, -1]], dim=1
                ),
                dim=1,
            ) + unary[t, :, PEDAL] + tail[1]
            o_prev, k_prev, p_prev = o_new, k_new, p_new
        final = torch.stack(
            [o_prev, torch.logsumexp(k_prev, dim=1), torch.logsumexp(p_prev, dim=1)], dim=1
        )
        return torch.logsumexp(final, dim=1).sum()

    def log_partition(
        self,
        unary: torch.Tensor,
        onset_logits: torch.Tensor,
        candidate_mask: torch.Tensor,
        pedal_logits: torch.Tensor,
    ) -> torch.Tensor:
        return torch.stack(
            [
                self._partition_one(unary[b], onset_logits[b], candidate_mask[b], pedal_logits[b])
                for b in range(unary.shape[0])
            ]
        )

    def path_score(
        self,
        unary: torch.Tensor,
        onset_logits: torch.Tensor,
        candidate_mask: torch.Tensor,
        pedal_logits: torch.Tensor,
        target_states: torch.Tensor,
    ) -> torch.Tensor:
        duration, tail = self.duration_increments()
        scores = []
        for b in range(unary.shape[0]):
            states = target_states[b]
            batch_score = unary.new_zeros(())
            run_length = torch.ones(self.pitches, device=unary.device, dtype=torch.long)
            previous = torch.full((self.pitches,), OFF, device=unary.device, dtype=torch.long)
            for t in range(unary.shape[1]):
                current = states[t]
                batch_score = batch_score + unary[b, t].gather(1, current[:, None]).sum()
                changed = current.ne(previous)
                same = ~changed
                invalid = changed & ~(
                    ((previous == OFF) & (current == KEY))
                    | ((previous == KEY) & (current == OFF))
                    | ((previous == KEY) & (current == PEDAL))
                    | ((previous == PEDAL) & (current == OFF))
                    | ((previous == PEDAL) & (current == KEY))
                )
                if invalid.any():
                    raise ValueError("Target path contains an illegal PACES state transition")
                onset_transition = changed & (current == KEY)
                if (onset_transition & ~candidate_mask[b, t]).any():
                    raise ValueError("Target onset is absent from the candidate union")
                batch_score = batch_score + (
                    ((previous == OFF) & (current == KEY)).float()
                    * (self.transition_bias["ok"] + onset_logits[b, t])
                ).sum()
                batch_score = batch_score + (
                    ((previous == PEDAL) & (current == KEY)).float()
                    * (self.transition_bias["pk"] + onset_logits[b, t])
                ).sum()
                log_down = F.logsigmoid(pedal_logits[b, t])
                log_up = F.logsigmoid(-pedal_logits[b, t])
                batch_score = batch_score + (
                    ((previous == KEY) & (current == PEDAL)).float()
                    * (self.transition_bias["kp"] + log_down)
                ).sum()
                batch_score = batch_score + (
                    ((previous == KEY) & (current == OFF)).float()
                    * (self.transition_bias["ko"] + log_up)
                ).sum()
                batch_score = batch_score + (
                    ((previous == PEDAL) & (current == OFF)).float()
                    * (self.transition_bias["po"] + log_up)
                ).sum()
                run_length = torch.where(changed, torch.ones_like(run_length), run_length + same.long())
                for semantic, row in ((KEY, 0), (PEDAL, 1)):
                    active = current == semantic
                    if active.any():
                        length = run_length[active]
                        lookup_index = (length - 1).clamp(max=self.duration_frames - 1)
                        increments = duration[row, lookup_index]
                        increments = torch.where(length > self.duration_frames, tail[row], increments)
                        batch_score = batch_score + increments.sum()
                previous = current
            scores.append(batch_score)
        return torch.stack(scores)

    def negative_log_likelihood(
        self,
        unary: torch.Tensor,
        onset_logits: torch.Tensor,
        candidate_mask: torch.Tensor,
        pedal_logits: torch.Tensor,
        target_states: torch.Tensor,
    ) -> torch.Tensor:
        return self.log_partition(unary, onset_logits, candidate_mask, pedal_logits) - self.path_score(
            unary, onset_logits, candidate_mask, pedal_logits, target_states
        )

    @torch.no_grad()
    def viterbi_decode(
        self,
        unary: torch.Tensor,
        onset_logits: torch.Tensor,
        candidate_mask: torch.Tensor,
        pedal_logits: torch.Tensor,
    ) -> list[ViterbiResult]:
        return [
            self._viterbi_one(unary[b], onset_logits[b], candidate_mask[b], pedal_logits[b])
            for b in range(unary.shape[0])
        ]

    def _viterbi_one(
        self,
        unary: torch.Tensor,
        onset_logits: torch.Tensor,
        candidate_mask: torch.Tensor,
        pedal_logits: torch.Tensor,
    ) -> ViterbiResult:
        frames, pitches, _ = unary.shape
        duration, tail = self.duration_increments()
        neg_inf = torch.tensor(float("-inf"), device=unary.device, dtype=unary.dtype)
        o_prev = torch.zeros(pitches, device=unary.device, dtype=unary.dtype)
        k_prev = unary.new_full((pitches, self.duration_frames + 1), float("-inf"))
        p_prev = unary.new_full((pitches, self.duration_frames + 1), float("-inf"))
        bp_o_src, bp_o_dur = [], []
        bp_k_src, bp_k_dur, bp_p_dur = [], [], []
        bp_ktail, bp_ptail = [], []
        for t in range(frames):
            log_down, log_up = F.logsigmoid(pedal_logits[t]), F.logsigmoid(-pedal_logits[t])
            k_best, k_best_d = k_prev.max(dim=1)
            p_best, p_best_d = p_prev.max(dim=1)
            if t == 0:
                o_sources = torch.stack([o_prev, o_prev.new_full(o_prev.shape, float("-inf")), o_prev.new_full(o_prev.shape, float("-inf"))], dim=1)
            else:
                o_sources = torch.stack(
                    [o_prev, k_best + self.transition_bias["ko"] + log_up, p_best + self.transition_bias["po"] + log_up], dim=1
                )
            o_value, o_source = o_sources.max(dim=1)
            o_new = o_value + unary[t, :, OFF]
            o_duration = torch.where(o_source == KEY, k_best_d, torch.where(o_source == PEDAL, p_best_d, 0))

            gate = torch.where(candidate_mask[t], onset_logits[t], neg_inf)
            k_sources = torch.stack(
                [o_prev + self.transition_bias["ok"] + gate, p_best + self.transition_bias["pk"] + gate], dim=1
            )
            k_value, k_source_binary = k_sources.max(dim=1)
            k_new = unary.new_full(k_prev.shape, float("-inf"))
            k_new[:, 0] = k_value + unary[t, :, KEY] + duration[0, 0]
            k_new[:, 1 : self.duration_frames] = k_prev[:, : self.duration_frames - 1] + unary[t, :, KEY, None] + duration[0, 1:][None]
            k_tail_sources = torch.stack([k_prev[:, self.duration_frames - 1], k_prev[:, -1]], dim=1)
            k_tail_value, k_tail_source = k_tail_sources.max(dim=1)
            k_new[:, -1] = k_tail_value + unary[t, :, KEY] + tail[0]

            p_new = unary.new_full(p_prev.shape, float("-inf"))
            p_new[:, 0] = k_best + self.transition_bias["kp"] + log_down + unary[t, :, PEDAL] + duration[1, 0]
            p_new[:, 1 : self.duration_frames] = p_prev[:, : self.duration_frames - 1] + unary[t, :, PEDAL, None] + duration[1, 1:][None]
            p_tail_sources = torch.stack([p_prev[:, self.duration_frames - 1], p_prev[:, -1]], dim=1)
            p_tail_value, p_tail_source = p_tail_sources.max(dim=1)
            p_new[:, -1] = p_tail_value + unary[t, :, PEDAL] + tail[1]

            bp_o_src.append(o_source.to(torch.int8)); bp_o_dur.append(o_duration.to(torch.int16))
            bp_k_src.append(torch.where(k_source_binary == 0, OFF, PEDAL).to(torch.int8)); bp_k_dur.append(p_best_d.to(torch.int16))
            bp_p_dur.append(k_best_d.to(torch.int16)); bp_ktail.append(k_tail_source.to(torch.int8)); bp_ptail.append(p_tail_source.to(torch.int8))
            o_prev, k_prev, p_prev = o_new, k_new, p_new

        k_best, k_dur = k_prev.max(dim=1); p_best, p_dur = p_prev.max(dim=1)
        final = torch.stack([o_prev, k_best, p_best], dim=1)
        best_score, final_state = final.max(dim=1)
        states = torch.empty((frames, pitches), device=unary.device, dtype=torch.long)
        state = final_state.clone(); dur = torch.where(state == KEY, k_dur, torch.where(state == PEDAL, p_dur, 0))
        for t in range(frames - 1, -1, -1):
            states[t] = state
            if t == 0:
                break
            next_state, next_dur = state.clone(), dur.clone()
            for pitch in range(pitches):
                s, d = int(state[pitch]), int(dur[pitch])
                if s == OFF:
                    next_state[pitch] = bp_o_src[t][pitch]
                    next_dur[pitch] = bp_o_dur[t][pitch]
                elif s == KEY:
                    if d == 0:
                        src = int(bp_k_src[t][pitch]); next_state[pitch] = src
                        next_dur[pitch] = bp_k_dur[t][pitch] if src == PEDAL else 0
                    elif d == self.duration_frames:
                        next_state[pitch] = KEY
                        next_dur[pitch] = self.duration_frames if int(bp_ktail[t][pitch]) else self.duration_frames - 1
                    else:
                        next_state[pitch] = KEY; next_dur[pitch] = d - 1
                else:
                    if d == 0:
                        next_state[pitch] = KEY; next_dur[pitch] = bp_p_dur[t][pitch]
                    elif d == self.duration_frames:
                        next_state[pitch] = PEDAL
                        next_dur[pitch] = self.duration_frames if int(bp_ptail[t][pitch]) else self.duration_frames - 1
                    else:
                        next_state[pitch] = PEDAL; next_dur[pitch] = d - 1
            state, dur = next_state, next_dur
        return ViterbiResult(states=states, score=best_score.sum())
