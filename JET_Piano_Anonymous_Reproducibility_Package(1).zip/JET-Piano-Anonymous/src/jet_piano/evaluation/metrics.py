"""Recording-level discrimination, regression, calibration, and interval metrics."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from jet_piano.evaluation.matching import match_events
from jet_piano.inference.calibration import equal_mass_ece


def f1_from_counts(tp: int, fp: int, fn: int) -> float:
    denominator = 2 * tp + fp + fn
    return 0.0 if denominator == 0 else 2 * tp / denominator


def concordance_correlation(x: np.ndarray, y: np.ndarray) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 2:
        return float("nan")
    covariance = np.cov(x, y, ddof=1)[0, 1]
    return float(2 * covariance / (x.var(ddof=1) + y.var(ddof=1) + (x.mean() - y.mean()) ** 2))


def recording_metrics(reference: pd.DataFrame, estimate: pd.DataFrame) -> dict[str, float]:
    onset = match_events(
        reference.pitch.to_numpy(), reference.onset_s.to_numpy(),
        estimate.pitch.to_numpy(), estimate.onset_s.to_numpy(),
    )
    offset = match_events(
        reference.pitch.to_numpy(), reference.onset_s.to_numpy(),
        estimate.pitch.to_numpy(), estimate.onset_s.to_numpy(),
        reference_offset=reference.sounding_offset_s.to_numpy(),
        estimated_offset=estimate.sounding_offset_s.to_numpy(),
    )
    metrics: dict[str, float] = {
        "onset_f1": f1_from_counts(len(onset.reference_index), len(onset.false_positive_index), len(onset.false_negative_index)),
        "onset_offset_f1": f1_from_counts(len(offset.reference_index), len(offset.false_positive_index), len(offset.false_negative_index)),
    }
    if len(offset.reference_index):
        ref_duration = reference.sounding_offset_s.to_numpy()[offset.reference_index] - reference.onset_s.to_numpy()[offset.reference_index]
        est_duration = estimate.sounding_offset_s.to_numpy()[offset.estimated_index] - estimate.onset_s.to_numpy()[offset.estimated_index]
        metrics["duration_mae_s"] = float(np.mean(np.abs(ref_duration - est_duration)))
        if "key_release_s" in reference and "key_release_s" in estimate:
            metrics["key_off_mae_ms"] = float(
                1000 * np.mean(np.abs(reference.key_release_s.to_numpy()[offset.reference_index] - estimate.key_release_s.to_numpy()[offset.estimated_index]))
            )
        if "velocity" in reference and "velocity" in estimate:
            ref_velocity = reference.velocity.to_numpy()[offset.reference_index]
            est_velocity = estimate.velocity.to_numpy()[offset.estimated_index]
            metrics["velocity_mae"] = float(np.mean(np.abs(ref_velocity - est_velocity)))
            metrics["velocity_ccc"] = concordance_correlation(ref_velocity, est_velocity)
            velocity_valid = np.abs(ref_velocity - est_velocity) / 127.0 <= 0.10
            tp = int(velocity_valid.sum())
            metrics["velocity_aware_f1"] = f1_from_counts(
                tp,
                len(estimate) - tp,
                len(reference) - tp,
            )
    if "confidence" in estimate:
        correctness = np.zeros(len(estimate), dtype=float)
        correctness[onset.estimated_index] = 1.0
        probability = estimate.confidence.to_numpy(dtype=float)
        metrics["ece"] = equal_mass_ece(probability, correctness, bins=15)
        metrics["brier"] = float(np.mean((probability - correctness) ** 2))
        metrics["nll"] = float(-np.mean(correctness * np.log(np.clip(probability, 1e-8, 1)) + (1 - correctness) * np.log(np.clip(1 - probability, 1e-8, 1))))
    if {"velocity_lower", "velocity_upper", "velocity"}.issubset(estimate.columns) and "velocity" in reference:
        ref_velocity = reference.velocity.to_numpy()[offset.reference_index]
        lower = estimate.velocity_lower.to_numpy()[offset.estimated_index]
        upper = estimate.velocity_upper.to_numpy()[offset.estimated_index]
        metrics["velocity_interval_coverage"] = float(np.mean((ref_velocity >= lower) & (ref_velocity <= upper)))
        metrics["velocity_interval_width"] = float(np.mean(upper - lower))
    return metrics


def summarize_recordings(frame: pd.DataFrame, metrics: list[str]) -> dict[str, dict[str, float]]:
    summary = {}
    for metric in metrics:
        values = frame[metric].dropna().to_numpy(dtype=float)
        mean = values.mean(); sd = values.std(ddof=1)
        se = sd / np.sqrt(len(values))
        summary[metric] = {"mean": float(mean), "sd": float(sd), "ci95_low": float(mean - 1.96 * se), "ci95_high": float(mean + 1.96 * se), "n": int(len(values))}
    return summary
