#!/usr/bin/env python3
"""Rescore baseline event exports with the identical MAESTRO metric code."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from jet_piano.evaluation.io import maestro_reference
from jet_piano.evaluation.metrics import recording_metrics, summarize_recordings


def main() -> None:
    parser = argparse.ArgumentParser(description="Common-fold baseline event scorer")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--maestro-root", required=True)
    parser.add_argument("--model-name", required=True)
    parser.add_argument("--events-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    manifest = pd.read_csv(args.manifest)
    root = Path(args.events_root)
    rows = []
    for _, item in manifest.iterrows():
        path = root / f"{item.recording_id}.csv"
        if not path.is_file():
            raise FileNotFoundError(f"Missing baseline event export: {path}")
        estimate = pd.read_csv(path)
        required = {"onset_s", "offset_s", "pitch"}
        if not required.issubset(estimate.columns):
            raise ValueError(f"{path} lacks {sorted(required - set(estimate.columns))}")
        estimate = estimate.rename(columns={"offset_s": "sounding_offset_s"})
        if "key_release_s" not in estimate:
            estimate["key_release_s"] = estimate["sounding_offset_s"]
        reference = maestro_reference(Path(args.maestro_root) / item.label_path)
        metrics = recording_metrics(reference, estimate)
        rows.append({
            "model": args.model_name,
            "recording_id": item.recording_id,
            "work_id": item.work_id,
            "outer_fold": int(item.outer_fold),
            **metrics,
        })

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(output / "recording_metrics.csv", index=False)
    frame.groupby("outer_fold").mean(numeric_only=True).reset_index().to_csv(
        output / "fold_metrics.csv", index=False
    )
    metric_columns = [
        column for column in frame.columns
        if column not in {"model", "recording_id", "work_id", "outer_fold"}
    ]
    summary = {"model": args.model_name, **summarize_recordings(frame, metric_columns)}
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
