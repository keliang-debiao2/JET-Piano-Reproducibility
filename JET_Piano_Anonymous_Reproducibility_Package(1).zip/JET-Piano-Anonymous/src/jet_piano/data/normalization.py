"""Outer-training-only robust feature statistics."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import torch

from jet_piano.data.datasets import read_audio
from jet_piano.data.features import AcousticFeatureExtractor


@torch.no_grad()
def fit_robust_feature_statistics(
    extractor: AcousticFeatureExtractor,
    manifest: pd.DataFrame,
    root: str | Path,
    device: torch.device,
    frames_per_recording: int = 512,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Estimate per-band median and IQR from deterministic frame samples.

    Sampling is uniform over time within each outer-training recording, so no
    validation, calibration, outer-test, or external frame contributes.
    """
    root = Path(root)
    extractor = extractor.to(device).eval()
    samples = []
    for _, row in manifest.sort_values("recording_id").iterrows():
        waveform = torch.from_numpy(read_audio(root / row.audio_path, extractor.sample_rate))
        chunk_samples = 60 * extractor.sample_rate
        recording_samples = []
        chunks = max(1, (waveform.numel() + chunk_samples - 1) // chunk_samples)
        per_chunk = max(1, (int(frames_per_recording) + chunks - 1) // chunks)
        for start in range(0, waveform.numel(), chunk_samples):
            chunk = waveform[start : start + chunk_samples].to(device)
            features = extractor(chunk.unsqueeze(0))[0]
            count = min(per_chunk, features.shape[0])
            index = torch.linspace(0, features.shape[0] - 1, count, device=device).round().long()
            recording_samples.append(features[index].cpu())
        samples.append(torch.cat(recording_samples, dim=0)[:frames_per_recording])
    if not samples:
        raise ValueError("Cannot fit normalization from an empty training manifest")
    frame = torch.cat(samples, dim=0)
    median = frame.quantile(0.50, dim=0)
    iqr = frame.quantile(0.75, dim=0) - frame.quantile(0.25, dim=0)
    return median, iqr.clamp_min(1e-6)
