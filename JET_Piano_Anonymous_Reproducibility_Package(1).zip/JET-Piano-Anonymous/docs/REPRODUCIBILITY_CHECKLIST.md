# Reproducibility Checklist

## Before training

- [ ] Official MAESTRO v3.0.0 archive and metadata are unchanged.
- [ ] MusicNet solo-piano manifest contains 156 recordings and 62 work clusters.
- [ ] Archive and manifest SHA-256 checksums are recorded.
- [ ] No normalized work or duplicate checksum crosses an outer fold.
- [ ] Fold sizes are 255, 255, 255, 255, and 256.
- [ ] Segments were generated after group assignment.
- [ ] Preprocessing statistics are fitted inside each outer-training partition.
- [ ] Inner selection, calibration, and outer-test partitions are disjoint.

## During training

- [ ] Resolved configuration and seed are saved before epoch 1.
- [ ] The training log identifies the outer fold and ablation variant.
- [ ] Checkpoint selection uses grouped inner validation only.
- [ ] Early stopping uses the prespecified composite and patience of five epochs.
- [ ] Gradient accumulation, mixed precision, and clipping are recorded.
- [ ] GRCT weights are updated only from training-group losses.
- [ ] MusicNet data are not loaded by a training or selection process.

## Calibration and inference

- [ ] Onset threshold is selected on development data.
- [ ] Temperature is fitted from one-to-one matched accepted predictions in the calibration subset.
- [ ] The conformal residual quantile uses matched calibration events only.
- [ ] Calibration does not change candidate selection or the Viterbi path.
- [ ] Hann fusion occurs before sigmoid, candidate selection, and decoding.
- [ ] External checkpoint aggregation is frozen before MusicNet evaluation.
- [ ] Exactly one performance-level decoder pass is used externally.

## Evaluation

- [ ] Every MAESTRO performance has exactly one out-of-fold prediction.
- [ ] Metrics are first calculated per recording and then macro-averaged.
- [ ] Work clusters are the inferential resampling unit.
- [ ] MusicNet onset is the primary external endpoint.
- [ ] MusicNet velocity and pedal metrics are absent.
- [ ] Published-study comparisons are marked contextual when protocols differ.
- [ ] Ablations are retrained rather than masked only at inference.
- [ ] Holm correction covers the six prespecified paired comparisons.

## Anonymous release

- [ ] No names, affiliations, emails, ORCIDs, acknowledgements, or grant numbers appear.
- [ ] No local usernames, home directories, hostnames, tokens, or private URLs appear.
- [ ] No dataset audio, MIDI, labels, or third-party weights are included.
- [ ] Simulated reference logs remain visibly labelled and separate from real logs.
- [ ] Real logs, when available, include resolved config, revision, seed, manifest checksum, and hardware metadata.
