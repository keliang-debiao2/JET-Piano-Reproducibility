#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml

from jet_piano.data.datasets import read_audio
from jet_piano.evaluation.io import maestro_reference
from jet_piano.evaluation.matching import match_events
from jet_piano.inference.calibration import SplitConformalVelocity, TemperatureScaler, equal_mass_ece
from jet_piano.inference.pipeline import decode_fused, encode_performance, load_checkpoint
from jet_piano.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Fit fold-specific temperature and conformal quantile")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--manifest", default="manifests/maestro_folds.csv")
    parser.add_argument("--maestro-root", default=os.environ.get("MAESTRO_ROOT"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if not args.maestro_root:
        raise SystemExit("Set --maestro-root or MAESTRO_ROOT")
    run = Path(args.run_dir)
    config = yaml.safe_load((run / "resolved_config.yaml").read_text())
    fold = int(config["fold_config"]["fold"])
    threshold = float(config["fold_config"]["selected_onset_threshold"])
    manifest = pd.read_csv(args.manifest)
    calibration = manifest[manifest[f"is_calibration_o{fold}"]]
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model = load_checkpoint(run / "checkpoint_best.pt", config, device)
    margins, correctness = [], []
    velocity_target, velocity_mean, velocity_scale = [], [], []
    for _, row in calibration.iterrows():
        waveform = torch.from_numpy(
            read_audio(Path(args.maestro_root) / row.audio_path, config["data"]["sample_rate"])
        )
        fused = encode_performance(model, waveform, config, device)
        estimate = decode_fused(model, fused, threshold, temperature=1.0, include_velocity=True)
        reference = maestro_reference(Path(args.maestro_root) / row.label_path)
        matched = match_events(reference.pitch, reference.onset_s, estimate.pitch, estimate.onset_s)
        labels = np.zeros(len(estimate), dtype=float)
        labels[matched.estimated_index] = 1.0
        probability = estimate.confidence.to_numpy(float)
        margins.extend(
            np.log(
                np.clip(probability, 1e-8, 1 - 1e-8)
                / np.clip(1 - probability, 1e-8, 1)
            ).tolist()
        )
        correctness.extend(labels.tolist())
        if len(matched.reference_index):
            velocity_target.extend(
                (reference.velocity.to_numpy(float)[matched.reference_index] / 127.0).tolist()
            )
            velocity_mean.extend(
                (estimate.velocity.to_numpy(float)[matched.estimated_index] / 127.0).tolist()
            )
            velocity_scale.extend(
                estimate.velocity_scale_normalized.to_numpy(float)[matched.estimated_index].tolist()
            )
    margin_tensor = torch.tensor(margins, device=device)
    correctness_tensor = torch.tensor(correctness, device=device)
    temperature = TemperatureScaler().fit(margin_tensor, correctness_tensor)
    conformal = SplitConformalVelocity(alpha=config["validation"]["conformal_alpha"])
    quantile = conformal.fit(
        np.asarray(velocity_target), np.asarray(velocity_mean), np.asarray(velocity_scale)
    )
    uncalibrated = 1 / (1 + np.exp(-np.asarray(margins)))
    calibrated = 1 / (1 + np.exp(-np.asarray(margins) / temperature))
    result = {
        "fold": fold,
        "temperature": temperature,
        "conformal_quantile": quantile,
        "calibration_predictions": len(margins),
        "velocity_calibration_events": len(velocity_target),
        "ece_uncalibrated": equal_mass_ece(uncalibrated, np.asarray(correctness), 15),
        "ece_calibrated": equal_mass_ece(calibrated, np.asarray(correctness), 15),
        "source": "development_calibration_only",
    }
    write_json(args.output, result)
    print(result)


if __name__ == "__main__":
    main()
