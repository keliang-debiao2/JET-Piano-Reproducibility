# Synthetic and Structural Checks

Files in this directory are generated without research data. They demonstrate
that package structure, tensor shapes, decoding constraints, and command entry
points are valid. They do not estimate model accuracy and must not be cited as
scientific evidence.
