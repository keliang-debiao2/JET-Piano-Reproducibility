"""Exponential group-DRO weights with an exponential moving loss."""

from __future__ import annotations

import torch


class GroupDRO:
    def __init__(
        self,
        n_groups: int,
        eta: float = 0.01,
        ema: float = 0.90,
        device: torch.device | str = "cpu",
    ) -> None:
        self.eta = eta
        self.ema = ema
        self.weights = torch.full((n_groups,), 1.0 / n_groups, device=device)
        self.ema_loss = torch.zeros(n_groups, device=device)
        self.seen = torch.zeros(n_groups, dtype=torch.bool, device=device)

    @torch.no_grad()
    def update(self, group_losses: torch.Tensor, present: torch.Tensor) -> torch.Tensor:
        if group_losses.shape != self.weights.shape or present.shape != self.weights.shape:
            raise ValueError("Group loss and presence vectors must match the configured group count")
        self.ema_loss[present] = torch.where(
            self.seen[present],
            self.ema * self.ema_loss[present] + (1.0 - self.ema) * group_losses[present],
            group_losses[present],
        )
        self.seen |= present
        if self.eta > 0:
            logits = self.weights.clamp_min(1e-12).log() + self.eta * self.ema_loss
            logits = logits.masked_fill(~self.seen, float("-inf"))
            self.weights = logits.softmax(dim=0)
        return self.weights.clone()

    def weighted_loss(self, group_losses: torch.Tensor, present: torch.Tensor) -> torch.Tensor:
        normalized = self.weights * present.float()
        normalized = normalized / normalized.sum().clamp_min(1e-12)
        return (normalized * group_losses).sum()

    def state_dict(self) -> dict[str, torch.Tensor | float]:
        return {
            "eta": self.eta,
            "ema": self.ema,
            "weights": self.weights,
            "ema_loss": self.ema_loss,
            "seen": self.seen,
        }
