#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import pandas as pd
import torch
import yaml

from jet_piano.data.datasets import read_audio
from jet_piano.evaluation.io import maestro_reference
from jet_piano.evaluation.metrics import recording_metrics, summarize_recordings
from jet_piano.inference.pipeline import decode_fused, encode_performance, load_checkpoint
from jet_piano.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate one out-of-fold prediction per MAESTRO performance")
    parser.add_argument("--runs", nargs=5, required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--maestro-root", default=os.environ.get("MAESTRO_ROOT"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if not args.maestro_root:
        raise SystemExit("Set --maestro-root or MAESTRO_ROOT")
    output = Path(args.output)
    (output / "predictions").mkdir(parents=True, exist_ok=True)
    manifest = pd.read_csv(args.manifest)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    metric_rows, seen = [], set()
    for run_name in args.runs:
        run = Path(run_name)
        config = yaml.safe_load((run / "resolved_config.yaml").read_text())
        fold = int(config["fold_config"]["fold"])
        threshold = json.loads((run / "threshold.json").read_text())["onset_threshold"]
        calibration = json.loads((run / "calibration.json").read_text())
        model = load_checkpoint(run / "checkpoint_best.pt", config, device)
        for _, row in manifest[manifest.outer_fold == fold].iterrows():
            if row.recording_id in seen:
                raise RuntimeError(f"Duplicate OOF prediction: {row.recording_id}")
            seen.add(row.recording_id)
            waveform = torch.from_numpy(
                read_audio(Path(args.maestro_root) / row.audio_path, config["data"]["sample_rate"])
            )
            fused = encode_performance(model, waveform, config, device)
            estimate = decode_fused(
                model,
                fused,
                threshold,
                calibration["temperature"],
                calibration["conformal_quantile"],
                include_velocity=True,
            )
            estimate.insert(0, "recording_id", row.recording_id)
            estimate.insert(1, "work_id", row.work_id)
            estimate.to_parquet(output / "predictions" / f"{row.recording_id}.parquet", index=False)
            reference = maestro_reference(Path(args.maestro_root) / row.label_path)
            metrics = recording_metrics(reference, estimate)
            metric_rows.append(
                {"recording_id": row.recording_id, "work_id": row.work_id, "outer_fold": fold, **metrics}
            )
    if len(seen) != len(manifest):
        raise RuntimeError(f"Expected {len(manifest)} OOF recordings, produced {len(seen)}")
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(output / "recording_metrics.csv", index=False)
    metric_columns = [
        column for column in metrics.columns if column not in {"recording_id", "work_id", "outer_fold"}
    ]
    summary = summarize_recordings(metrics, metric_columns)
    metrics.groupby("outer_fold").mean(numeric_only=True).reset_index().to_csv(
        output / "fold_metrics.csv", index=False
    )
    write_json(output / "summary.json", summary)
    print(summary)


if __name__ == "__main__":
    main()
