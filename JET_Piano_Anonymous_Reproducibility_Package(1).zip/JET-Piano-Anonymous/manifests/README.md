# Generated manifests

This directory is intentionally empty in the anonymous package. Run `scripts/build_manifests.py` and `scripts/make_folds.py` after downloading the public datasets. Generated CSV, JSON, and checksum files are ignored by Git because they may reveal local dataset organization.
