import pandas as pd

from jet_piano.data.folds import assign_grouped_folds, audit_fold_leakage


def test_work_identity_never_crosses_fold():
    frame = pd.DataFrame({"recording_id": [f"r{i}" for i in range(12)], "work_id": [f"w{i // 2}" for i in range(12)], "year": [2018, 2019, 2020] * 4, "duration_s": [60 + i for i in range(12)], "pitch_density": [1 + i / 10 for i in range(12)], "audio_sha256": [f"a{i}" for i in range(12)], "label_sha256": [f"l{i}" for i in range(12)]})
    frame["outer_fold"] = assign_grouped_folds(frame, n_folds=3, seed=7)
    audit_fold_leakage(frame)
    assert frame.groupby("work_id").outer_fold.nunique().max() == 1
