"""Synchronized latency and peak-memory measurement."""

from __future__ import annotations

import time
from typing import Callable

import numpy as np
import torch


@torch.no_grad()
def benchmark(
    function: Callable[[], object],
    clip_seconds: float,
    warmup: int = 10,
    repetitions: int = 100,
) -> dict[str, float]:
    for _ in range(warmup):
        function()
    if torch.cuda.is_available():
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
    timings = []
    for _ in range(repetitions):
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        start = time.perf_counter(); function()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        timings.append(time.perf_counter() - start)
    peak = torch.cuda.max_memory_allocated() / 1e9 if torch.cuda.is_available() else float("nan")
    return {"median_s": float(np.median(timings)), "p95_s": float(np.quantile(timings, 0.95)), "real_time_factor": float(np.median(timings) / clip_seconds), "peak_memory_gb": float(peak)}
