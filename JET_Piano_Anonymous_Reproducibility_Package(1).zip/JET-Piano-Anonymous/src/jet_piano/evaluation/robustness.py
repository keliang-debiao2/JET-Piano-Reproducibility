"""Post-training perturbations that preserve reference event labels."""

from __future__ import annotations

import io

import numpy as np
import torch
from scipy.signal import butter, sosfilt


def additive_noise(waveform: torch.Tensor, snr_db: float, generator: torch.Generator | None = None) -> torch.Tensor:
    signal_power = waveform.square().mean(dim=-1, keepdim=True).clamp_min(1e-12)
    noise_power = signal_power / (10 ** (snr_db / 10))
    noise = torch.randn(waveform.shape, device=waveform.device, dtype=waveform.dtype, generator=generator)
    noise = noise / noise.square().mean(dim=-1, keepdim=True).sqrt().clamp_min(1e-12)
    return waveform + noise * noise_power.sqrt()


def random_equalization(waveform: np.ndarray, sample_rate: int, db: float = 6.0, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    cutoff = float(rng.uniform(200.0, min(8000.0, sample_rate / 2 - 100)))
    gain = float(10 ** (rng.uniform(-db, db) / 20))
    sos = butter(2, cutoff, btype="low", fs=sample_rate, output="sos")
    low = sosfilt(sos, waveform)
    return (waveform + (gain - 1.0) * low).astype(np.float32)


def contiguous_frame_mask(features: torch.Tensor, fraction: float = 0.10, start: int | None = None) -> torch.Tensor:
    output = features.clone()
    width = max(1, int(round(features.shape[1] * fraction)))
    start = int(start if start is not None else max(0, (features.shape[1] - width) // 2))
    output[:, start : start + width] = 0
    return output
