"""Linear representation probes used as descriptive, non-causal diagnostics."""

from __future__ import annotations

import numpy as np
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import accuracy_score

from jet_piano.evaluation.metrics import concordance_correlation


def pitch_probe(train_code: np.ndarray, train_pitch: np.ndarray, test_code: np.ndarray, test_pitch: np.ndarray) -> float:
    model = LogisticRegression(max_iter=1000, class_weight="balanced", n_jobs=1)
    model.fit(train_code, train_pitch)
    return float(accuracy_score(test_pitch, model.predict(test_code)))


def velocity_probe(train_code: np.ndarray, train_velocity: np.ndarray, test_code: np.ndarray, test_velocity: np.ndarray) -> float:
    model = Ridge(alpha=1.0)
    model.fit(train_code, train_velocity)
    return concordance_correlation(test_velocity, model.predict(test_code))
