"""Fold-specific optimization with train-only GRCT and frozen evaluation state."""

from __future__ import annotations

from collections import defaultdict
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F

from jet_piano.models.jet_piano import JETPiano
from jet_piano.training.group_dro import GroupDRO
from jet_piano.training.losses import (
    consistency_loss,
    masked_gaussian_nll,
    onset_proposal_loss,
    orthogonality_loss,
)
from jet_piano.utils import append_jsonl, utc_now


def reference_candidates(onset: torch.Tensor) -> list[torch.Tensor]:
    output = []
    for batch_index in range(onset.shape[0]):
        frame, pitch = torch.where(onset[batch_index] > 0.5)
        probability = torch.ones_like(frame, dtype=onset.dtype)
        output.append(torch.stack([frame, pitch, probability], dim=1))
    return output


def union_candidates(reference: list[torch.Tensor], proposed: list[torch.Tensor]) -> list[torch.Tensor]:
    output = []
    for ref, pred in zip(reference, proposed):
        if ref.numel() == 0:
            output.append(pred)
            continue
        if pred.numel() == 0:
            output.append(ref)
            continue
        merged: dict[tuple[int, int], torch.Tensor] = {}
        for row in torch.cat([ref, pred], dim=0):
            key = (int(row[0]), int(row[1]))
            if key not in merged or row[2] > merged[key][2]:
                merged[key] = row
        output.append(torch.stack(list(merged.values())))
    return output


def simple_audio_augmentation(waveform: torch.Tensor) -> torch.Tensor:
    scale = waveform.std(dim=1, keepdim=True).clamp_min(1e-5)
    noise = torch.randn_like(waveform) * scale * 0.01
    augmented = waveform + noise
    if waveform.shape[1] > 20:
        width = max(1, waveform.shape[1] // 100)
        start = torch.randint(0, waveform.shape[1] - width, (1,), device=waveform.device).item()
        augmented[:, start : start + width] = 0
    return augmented


class Trainer:
    def __init__(
        self,
        model: JETPiano,
        config: dict[str, Any],
        optimizer: torch.optim.Optimizer,
        scheduler: torch.optim.lr_scheduler.LRScheduler | None,
        group_dro: GroupDRO,
        output_dir: str | Path,
        device: torch.device,
    ) -> None:
        self.model = model
        self.config = config
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.group_dro = group_dro
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.device = device
        self.scaler = torch.amp.GradScaler("cuda", enabled=config["training"]["mixed_precision"] and device.type == "cuda")
        self.step_index = 0
        self.accumulated_steps = 0
        self.optimizer.zero_grad(set_to_none=True)

    def _candidate_mask(self, candidates: list[torch.Tensor], shape: torch.Size) -> torch.Tensor:
        mask = torch.zeros(shape, dtype=torch.bool, device=self.device)
        for batch_index, candidate_set in enumerate(candidates):
            if candidate_set.numel():
                mask[batch_index, candidate_set[:, 0].long(), candidate_set[:, 1].long()] = True
        return mask

    def _attribute_targets(
        self,
        outputs: dict[str, torch.Tensor],
        batch_targets: list[dict[str, torch.Tensor]],
    ) -> tuple[torch.Tensor, torch.Tensor]:
        count = outputs["event_frame"].shape[0]
        target = torch.zeros((count, 4), device=self.device)
        mask = torch.zeros((count, 4), device=self.device, dtype=torch.bool)
        for index in range(count):
            batch = int(outputs["event_batch"][index])
            frame = int(outputs["event_frame"][index])
            pitch = int(outputs["event_pitch"][index]) + self.model.midi_min
            events = batch_targets[batch]["events"].to(self.device)
            if not events.numel():
                continue
            event_frames = torch.round(events[:, 0] / self.model.features.frame_seconds).long()
            matches = torch.where((event_frames == frame) & (events[:, 3].long() == pitch))[0]
            if matches.numel() != 1:
                continue
            event = events[matches[0]]
            onset, key_end, sound_end, _, velocity = event
            target[index, 0] = velocity / 127.0
            target[index, 1] = 0.0
            target[index, 2] = torch.log((key_end - onset).clamp_min(1e-4))
            target[index, 3] = ((sound_end - key_end).clamp_min(0) / (key_end - onset).clamp_min(1e-4))
            mask[index] = True
        return target, mask

    def train_step(self, batch: dict[str, Any], group_ids: torch.Tensor) -> dict[str, float]:
        self.model.train()
        waveform = batch["waveform"].to(self.device)
        targets = [item["targets"] for item in batch["items"]]
        amp = torch.amp.autocast("cuda", enabled=self.scaler.is_enabled()) if self.device.type == "cuda" else nullcontext()
        with amp:
            encoded = self.model.encode(waveform)
            frames = encoded["onset_logits"].shape[1]
            pitches = encoded["onset_logits"].shape[2]
            onset = torch.zeros(len(targets), frames, pitches, device=self.device)
            states = torch.zeros(len(targets), frames, pitches, device=self.device, dtype=torch.long)
            for index, item in enumerate(targets):
                length = min(frames, item["onset"].shape[0])
                onset[index, :length] = item["onset"][:length].to(self.device)
                states[index, :length] = item["states"][:length].to(self.device)
            proposed = self.model.pooling.select_candidates(encoded["onset_logits"].detach(), 0.35)
            candidates = union_candidates(reference_candidates(onset), proposed)
            outputs = self.model.forward_from_encoded(encoded, candidates)
            candidate_mask = self._candidate_mask(candidates, encoded["onset_logits"].shape)
            event_loss = self.model.paces.negative_log_likelihood(
                outputs["unary_logits"], outputs["onset_logits"], candidate_mask,
                outputs["pedal_logits"], states,
            )
            proposal_loss = onset_proposal_loss(
                outputs["onset_logits"], onset, self.config["training"]["onset_positive_weight"]
            )
            attribute_target, attribute_mask = self._attribute_targets(outputs, targets)
            expression_loss = masked_gaussian_nll(
                outputs["attribute_mean"], outputs["attribute_log_variance"],
                attribute_target, attribute_mask,
                self.config["model"]["cerd"]["variance_min"],
                self.config["model"]["cerd"]["variance_max"],
            )
            orth = orthogonality_loss(outputs)
            augmented = self.model(simple_audio_augmentation(waveform), candidates)
            consistency = consistency_loss(outputs, augmented, attribute_mask)
            per_example = event_loss + self.config["training"]["lambda_q"] * proposal_loss
            per_example = per_example + self.config["training"]["lambda_expression"] * expression_loss
            group_losses = torch.zeros_like(self.group_dro.weights)
            present = torch.zeros_like(self.group_dro.seen)
            for group in group_ids.unique():
                group_losses[group] = per_example[group_ids == group].mean()
                present[group] = True
            self.group_dro.update(group_losses.detach(), present)
            main = self.group_dro.weighted_loss(group_losses, present)
            loss = main + self.config["training"]["selected_lambda_orth"] * orth
            loss = loss + self.config["training"]["selected_lambda_consistency"] * consistency
            unscaled_loss = loss
            accumulation = int(self.config["training"]["gradient_accumulation_steps"])
            loss = unscaled_loss / accumulation
        self.scaler.scale(loss).backward()
        self.accumulated_steps += 1
        if self.accumulated_steps == accumulation:
            self._optimizer_step()
            self.accumulated_steps = 0
        self.step_index += 1
        record = {
            "time_utc": utc_now(), "step": self.step_index, "loss": float(unscaled_loss.detach()),
            "event_nll": float(event_loss.mean().detach()), "proposal_bce": float(proposal_loss.detach()),
            "expression_nll": float(expression_loss.detach()), "orthogonality": float(orth.detach()),
            "consistency": float(consistency.detach()),
            "group_weights": self.group_dro.weights.detach().cpu().tolist(),
        }
        append_jsonl(self.output_dir / "train.jsonl", record)
        return {key: value for key, value in record.items() if isinstance(value, (int, float))}

    def _optimizer_step(self) -> None:
        self.scaler.unscale_(self.optimizer)
        nn.utils.clip_grad_norm_(
            self.model.parameters(), self.config["training"]["gradient_clip_norm"]
        )
        self.scaler.step(self.optimizer)
        self.scaler.update()
        self.optimizer.zero_grad(set_to_none=True)
        if self.scheduler is not None:
            self.scheduler.step()

    def flush_accumulation(self) -> None:
        if self.accumulated_steps:
            self._optimizer_step()
            self.accumulated_steps = 0
