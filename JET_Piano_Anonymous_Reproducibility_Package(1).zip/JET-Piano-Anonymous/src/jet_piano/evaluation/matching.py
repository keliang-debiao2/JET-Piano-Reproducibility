"""One-to-one pitch-constrained event matching used by metrics and calibration."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import linear_sum_assignment


@dataclass(frozen=True)
class MatchResult:
    reference_index: np.ndarray
    estimated_index: np.ndarray
    false_negative_index: np.ndarray
    false_positive_index: np.ndarray


def match_events(
    reference_pitch: np.ndarray,
    reference_onset: np.ndarray,
    estimated_pitch: np.ndarray,
    estimated_onset: np.ndarray,
    onset_tolerance_s: float = 0.050,
    reference_offset: np.ndarray | None = None,
    estimated_offset: np.ndarray | None = None,
    offset_tolerance_s: float = 0.050,
    offset_ratio: float = 0.20,
) -> MatchResult:
    reference_pitch = np.asarray(reference_pitch, dtype=int)
    estimated_pitch = np.asarray(estimated_pitch, dtype=int)
    reference_onset = np.asarray(reference_onset, dtype=float)
    estimated_onset = np.asarray(estimated_onset, dtype=float)
    cost = np.full((len(reference_pitch), len(estimated_pitch)), 1e6, dtype=float)
    for ref in range(len(reference_pitch)):
        candidates = np.where(estimated_pitch == reference_pitch[ref])[0]
        onset_error = np.abs(estimated_onset[candidates] - reference_onset[ref])
        valid = onset_error <= onset_tolerance_s
        if reference_offset is not None and estimated_offset is not None:
            tolerance = np.maximum(
                offset_tolerance_s,
                offset_ratio * np.maximum(reference_offset[ref] - reference_onset[ref], 0.0),
            )
            valid &= np.abs(estimated_offset[candidates] - reference_offset[ref]) <= tolerance
        cost[ref, candidates[valid]] = onset_error[valid]
    if cost.size:
        ref_index, est_index = linear_sum_assignment(cost)
        valid = cost[ref_index, est_index] < 1e6
        ref_index, est_index = ref_index[valid], est_index[valid]
    else:
        ref_index = np.zeros(0, dtype=int); est_index = np.zeros(0, dtype=int)
    fn = np.setdiff1d(np.arange(len(reference_pitch)), ref_index)
    fp = np.setdiff1d(np.arange(len(estimated_pitch)), est_index)
    return MatchResult(ref_index, est_index, fn, fp)
