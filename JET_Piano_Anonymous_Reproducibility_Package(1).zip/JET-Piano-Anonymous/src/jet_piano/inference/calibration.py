"""Development-only temperature scaling and split-conformal velocity intervals."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch.nn import functional as F


class TemperatureScaler:
    def __init__(self, temperature: float = 1.0) -> None:
        if temperature <= 0:
            raise ValueError("Temperature must be positive")
        self.temperature = float(temperature)

    def fit(self, margins: torch.Tensor, correctness: torch.Tensor, max_iter: int = 100) -> float:
        log_temperature = torch.tensor(
            np.log(self.temperature), device=margins.device, dtype=margins.dtype, requires_grad=True
        )
        optimizer = torch.optim.LBFGS([log_temperature], max_iter=max_iter, line_search_fn="strong_wolfe")

        def closure() -> torch.Tensor:
            optimizer.zero_grad()
            temperature = log_temperature.exp()
            loss = F.binary_cross_entropy_with_logits(margins / temperature, correctness.float())
            loss.backward()
            return loss

        optimizer.step(closure)
        self.temperature = float(log_temperature.detach().exp().clamp_min(1e-6))
        return self.temperature

    def transform(self, margins: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(margins / self.temperature)


@dataclass
class SplitConformalVelocity:
    alpha: float = 0.10
    epsilon: float = 1e-6
    quantile: float | None = None

    def fit(self, target: np.ndarray, mean: np.ndarray, scale: np.ndarray) -> float:
        target, mean, scale = map(lambda value: np.asarray(value, dtype=float), (target, mean, scale))
        if not (target.shape == mean.shape == scale.shape) or target.size == 0:
            raise ValueError("Target, mean, and scale must be aligned non-empty arrays")
        scores = np.abs(target - mean) / np.maximum(scale, self.epsilon)
        rank = int(np.ceil((len(scores) + 1) * (1.0 - self.alpha)))
        rank = min(max(rank, 1), len(scores))
        self.quantile = float(np.partition(scores, rank - 1)[rank - 1])
        return self.quantile

    def interval(self, mean: np.ndarray, scale: np.ndarray, midi_units: bool = True) -> np.ndarray:
        if self.quantile is None:
            raise RuntimeError("Fit the conformal quantile before interval construction")
        mean, scale = np.asarray(mean, dtype=float), np.asarray(scale, dtype=float)
        interval = np.stack(
            [mean - self.quantile * scale, mean + self.quantile * scale], axis=-1
        ).clip(0.0, 1.0)
        return interval * 127.0 if midi_units else interval


def equal_mass_ece(probability: np.ndarray, target: np.ndarray, bins: int = 15) -> float:
    probability = np.asarray(probability, dtype=float)
    target = np.asarray(target, dtype=float)
    order = np.argsort(probability)
    groups = np.array_split(order, bins)
    total = len(probability)
    return float(
        sum(len(group) / total * abs(probability[group].mean() - target[group].mean()) for group in groups if len(group))
    )


def selective_risk(probability: np.ndarray, correctness: np.ndarray, coverages: np.ndarray) -> dict[str, np.ndarray]:
    probability = np.asarray(probability, dtype=float)
    correctness = np.asarray(correctness, dtype=float)
    order = np.argsort(-probability)
    risks, thresholds = [], []
    for coverage in coverages:
        retained = max(1, int(np.ceil(len(order) * float(coverage))))
        index = order[:retained]
        risks.append(float(1.0 - correctness[index].mean()))
        thresholds.append(float(probability[index].min()))
    return {"coverage": np.asarray(coverages), "risk": np.asarray(risks), "threshold": np.asarray(thresholds)}
