"""Content-expression residual disentangler and heteroscedastic heads."""

from __future__ import annotations

import math

import torch
from torch import nn


class ResidualProjection(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.skip = nn.Linear(input_dim, output_dim)
        self.body = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.skip(x) + self.body(x)


def sinusoidal_time_embedding(frames: torch.Tensor, dim: int) -> torch.Tensor:
    half = dim // 2
    scale = torch.exp(
        torch.arange(half, device=frames.device, dtype=torch.float32)
        * (-math.log(10000.0) / max(half - 1, 1))
    )
    angles = frames.float().unsqueeze(1) * scale.unsqueeze(0)
    embedding = torch.cat([angles.sin(), angles.cos()], dim=1)
    if embedding.shape[1] < dim:
        embedding = torch.cat([embedding, embedding.new_zeros((len(frames), 1))], dim=1)
    return embedding


class CERD(nn.Module):
    def __init__(
        self,
        event_dim: int = 256,
        summary_dim: int = 256,
        pitches: int = 88,
        pitch_embedding_dim: int = 32,
        time_embedding_dim: int = 32,
        content_dim: int = 128,
        expression_dim: int = 128,
        hidden_dim: int = 256,
        attributes: int = 4,
        shared_representation: bool = False,
    ) -> None:
        super().__init__()
        self.time_embedding_dim = time_embedding_dim
        self.shared_representation = shared_representation
        self.pitch_embedding = nn.Embedding(pitches, pitch_embedding_dim)
        self.content = ResidualProjection(
            event_dim + pitch_embedding_dim + time_embedding_dim, content_dim, hidden_dim
        )
        expression_input = event_dim + summary_dim + time_embedding_dim
        self.expression = ResidualProjection(expression_input, expression_dim, hidden_dim)
        if shared_representation:
            self.shared = ResidualProjection(
                event_dim + summary_dim + pitch_embedding_dim + time_embedding_dim,
                content_dim + expression_dim,
                hidden_dim,
            )
        self.attribute_heads = nn.ModuleList(
            nn.Sequential(
                nn.LayerNorm(content_dim + expression_dim),
                nn.Linear(content_dim + expression_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, 2),
            )
            for _ in range(attributes)
        )

    def forward(
        self,
        event_tokens: torch.Tensor,
        summary_context: torch.Tensor,
        frames: torch.Tensor,
        pitches: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        time = sinusoidal_time_embedding(frames, self.time_embedding_dim).to(event_tokens.dtype)
        pitch = self.pitch_embedding(pitches)
        if self.shared_representation:
            shared = self.shared(torch.cat([event_tokens, summary_context, pitch, time], dim=-1))
            content, expression = shared.chunk(2, dim=-1)
        else:
            content = self.content(torch.cat([event_tokens, pitch, time], dim=-1))
            expression = self.expression(torch.cat([event_tokens, summary_context, time], dim=-1))
        joint = torch.cat([expression, content], dim=-1)
        outputs = torch.stack([head(joint) for head in self.attribute_heads], dim=1)
        return {
            "content": content,
            "expression": expression,
            "attribute_mean": outputs[..., 0],
            "attribute_log_variance": outputs[..., 1],
        }


def cross_covariance_penalty(content: torch.Tensor, expression: torch.Tensor) -> torch.Tensor:
    if content.shape[0] < 2:
        return content.new_zeros(())
    content_centered = content - content.mean(dim=0, keepdim=True)
    expression_centered = expression - expression.mean(dim=0, keepdim=True)
    covariance = content_centered.transpose(0, 1) @ expression_centered / (content.shape[0] - 1)
    return covariance.square().sum()
