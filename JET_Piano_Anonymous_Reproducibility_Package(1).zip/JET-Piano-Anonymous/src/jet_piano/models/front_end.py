"""Boundary-preserving convolutional feature stem."""

from __future__ import annotations

import torch
from torch import nn


class DepthwiseSeparableBlock(nn.Module):
    def __init__(self, channels: int, kernel_size: int, groups: int, dropout: float = 0.0) -> None:
        super().__init__()
        padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=padding, groups=channels),
            nn.Conv1d(channels, channels, 1),
            nn.GroupNorm(min(groups, channels), channels),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.block(x)


class ConvStem(nn.Module):
    def __init__(
        self,
        input_dim: int = 253,
        latent_dim: int = 256,
        kernel_sizes: tuple[int, ...] = (5, 3),
        groups: int = 32,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.projection = nn.Conv1d(input_dim, latent_dim, 1)
        self.blocks = nn.ModuleList(
            DepthwiseSeparableBlock(latent_dim, kernel, groups, dropout) for kernel in kernel_sizes
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        x = self.projection(features.transpose(1, 2))
        for block in self.blocks:
            x = block(x)
        return x.transpose(1, 2)
