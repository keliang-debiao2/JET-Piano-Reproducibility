#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import torch

from jet_piano.config import load_config
from jet_piano.models import JETPiano
from jet_piano.utils import runtime_metadata, set_seed, utc_now, write_json


def small_config(config: dict) -> dict:
    config["model"]["latent_dim"] = 32
    config["model"]["conv_groups"] = 8
    config["model"]["dtat"].update({"layers": 2, "heads": 4, "local_window_frames": 16, "feedforward_dim": 64})
    config["model"]["paces"]["duration_lookup_frames"] = 16
    config["model"]["cerd"].update({"content_dim": 16, "expression_dim": 16, "pitch_embedding_dim": 8, "time_embedding_dim": 8, "hidden_dim": 32})
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a synthetic tensor smoke test; not a scientific experiment")
    parser.add_argument("--config", required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--output", default="logs/synthetic_smoke/smoke.json")
    args = parser.parse_args()
    config = small_config(load_config(args.config)); set_seed(12345)
    device = torch.device(args.device if args.device == "cpu" or torch.cuda.is_available() else "cpu")
    model = JETPiano(config).to(device).eval()
    waveform = torch.randn(1, config["data"]["sample_rate"] * 2, device=device) * 0.01
    candidates = [torch.tensor([[20.0, 40.0, 0.9], [60.0, 44.0, 0.9], [100.0, 47.0, 0.9]], device=device)]
    with torch.no_grad():
        outputs = model(waveform, candidate_sets=candidates)
        decoded = model.decode(outputs)[0]
    states = decoded.states if hasattr(decoded, "states") else decoded
    result = {
        "status": "PASS",
        "evidence_class": "SYNTHETIC_SMOKE_TEST_NOT_SCIENTIFIC_RESULT",
        "created_utc": utc_now(),
        "runtime": runtime_metadata(),
        "waveform_shape": list(waveform.shape),
        "acoustic_shape": list(outputs["acoustic"].shape),
        "onset_logits_shape": list(outputs["onset_logits"].shape),
        "unary_logits_shape": list(outputs["unary_logits"].shape),
        "candidate_count": int(outputs["event_frame"].numel()),
        "decoded_state_shape": list(states.shape),
        "parameters_small_smoke_model": model.parameter_count(),
        "checks": {"finite_onset_logits": bool(torch.isfinite(outputs["onset_logits"]).all()), "finite_attributes": bool(torch.isfinite(outputs["attribute_mean"]).all()), "decoded_states_valid": bool(torch.isin(states, torch.tensor([0, 1, 2], device=device)).all())},
    }
    if not all(result["checks"].values()): raise RuntimeError(result)
    write_json(args.output, result); print(result)


if __name__ == "__main__":
    main()
