#!/usr/bin/env python3
"""Create manuscript-style Figures 3--8 from standardized result tables.

By default this reads the explicitly simulated reference directory for layout
checking. Point ``--source-dir`` at a directory containing real tables with the
same schemas before producing archival figures.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def finish(fig: plt.Figure, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Render Figures 3--8")
    parser.add_argument("--source-dir", default="logs/simulated_reference")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    source, output = Path(args.source_dir), Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "serif", "font.size": 9})

    folds = pd.read_csv(source / "internal_five_fold.csv")
    metrics = [("onset_f1", "Onset F1 (%)"), ("onset_offset_f1", "Onset+offset F1 (%)"), ("velocity_aware_f1", "Velocity-aware F1 (%)")]
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.2))
    for ax, (column, label) in zip(axes, metrics):
        ax.plot(folds.fold, folds[column], "o-", color="#315b7d")
        ax.axhline(folds[column].mean(), color="#a5513a", lw=1)
        ax.set(xlabel="Outer fold", ylabel=label, xticks=folds.fold)
    finish(fig, output / "Figure3_five_fold_cv.png")

    baselines = pd.read_csv(source / "baselines_common_fold.csv").tail(6)
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.7))
    for ax, prefix, label in zip(axes, ["onset", "offset", "velocity"], ["Onset F1 (%)", "Onset+offset F1 (%)", "Velocity-aware F1 (%)"]):
        ax.barh(baselines.model, baselines[f"{prefix}_mean"], color="#7699b5")
        ax.errorbar(baselines[f"{prefix}_mean"], baselines.model, xerr=[baselines[f"{prefix}_mean"]-baselines[f"{prefix}_ci_low"], baselines[f"{prefix}_ci_high"]-baselines[f"{prefix}_mean"]], fmt="none", color="#333333", capsize=2)
        ax.set_xlabel(label)
    finish(fig, output / "Figure4_baseline_comparison.png")

    external = pd.read_csv(source / "external_validation.csv")
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6))
    columns = [("onset_f1", "onset_ci_low", "onset_ci_high", "Onset F1 (%)"), ("onset_offset_f1", "offset_ci_low", "offset_ci_high", "Onset+offset F1 (%)"), ("duration_mae_s", "duration_ci_low", "duration_ci_high", "Duration MAE (s)")]
    for ax, (value, low, high, label) in zip(axes, columns):
        ax.barh(external.model, external[value], color="#7b9f83")
        ax.errorbar(external[value], external.model, xerr=[external[value]-external[low], external[high]-external[value]], fmt="none", color="#333333", capsize=2)
        ax.set_xlabel(label)
    finish(fig, output / "Figure5_external_validation.png")

    ablations = pd.read_csv(source / "ablations.csv").iloc[1:]
    full = pd.read_csv(source / "ablations.csv").iloc[0]
    fig, axes = plt.subplots(1, 3, figsize=(11, 4.2))
    for ax, column, label in zip(axes, ["onset_mean", "offset_mean", "musicnet_onset_f1"], ["Change in onset F1 (pp)", "Change in onset+offset F1 (pp)", "Change in MusicNet onset F1 (pp)"]):
        change = ablations[column] - full[column]
        ax.barh(ablations.variant, change, color="#b77668")
        ax.axvline(0, color="#333333", lw=0.8)
        ax.set_xlabel(label)
    finish(fig, output / "Figure6_ablation.png")

    robust = pd.read_csv(source / "calibration_robustness.csv")
    calibration = robust[robust.analysis == "calibration"]
    perturb = robust[robust.analysis == "robustness"]
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.3))
    axes[0].bar(calibration.condition, calibration.ece, color="#8b79a6"); axes[0].set_ylabel("ECE"); axes[0].tick_params(axis="x", rotation=20)
    axes[1].bar(perturb.condition, perturb.onset_f1, color="#7699b5"); axes[1].set_ylabel("Onset F1 (%)"); axes[1].tick_params(axis="x", rotation=60)
    axes[2].bar(perturb.condition, perturb.onset_offset_f1, color="#7b9f83"); axes[2].set_ylabel("Onset+offset F1 (%)"); axes[2].tick_params(axis="x", rotation=60)
    finish(fig, output / "Figure7_calibration_robustness.png")

    stats = pd.read_csv(source / "paired_statistics.csv")
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.3))
    for index, row_index in enumerate([0, 1]):
        row = stats.iloc[row_index]
        axes[index].errorbar([row.mean_difference], [0], xerr=[[row.mean_difference-row.ci_low], [row.ci_high-row.mean_difference]], fmt="o", color="#315b7d", capsize=4)
        axes[index].axvline(0, color="#333333", ls="--"); axes[index].set_yticks([]); axes[index].set_xlabel(row.endpoint + " difference (pp)")
    axes[2].errorbar(stats.mean_difference, np.arange(len(stats)), xerr=[stats.mean_difference-stats.ci_low, stats.ci_high-stats.mean_difference], fmt="o", color="#a5513a", capsize=3)
    axes[2].axvline(0, color="#333333", ls="--"); axes[2].set_yticks(np.arange(len(stats)), stats.endpoint); axes[2].set_xlabel("Paired difference")
    finish(fig, output / "Figure8_paired_statistics.png")


if __name__ == "__main__":
    main()
