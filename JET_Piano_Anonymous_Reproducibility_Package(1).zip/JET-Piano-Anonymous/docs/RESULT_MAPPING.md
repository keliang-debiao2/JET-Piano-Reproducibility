# Output-to-Manuscript Mapping

| Manuscript item | Generated artifact | Producing command |
| --- | --- | --- |
| Table 1 | `manifests/dataset_characteristics.json` | `build_manifests.py` |
| Table 3 | `runs/hyperparameter_selection.csv` | `train_fold.py` aggregation |
| Table 4 and Figure 3 | `internal/fold_metrics.csv`, `internal/summary.json` | `evaluate_internal.py` |
| Table 5 and Figure 4 | `baselines/common_fold_comparison.csv` | baseline runner plus `evaluate_internal.py` |
| Table 6 and Figure 5 | `external_musicnet/external_metrics.csv` | `evaluate_external.py --zero-shot` |
| Table 8 and Figure 6 | `ablations/ablation_summary.csv` | `run_ablation.py` |
| Table 9 and Figure 7 | `robustness/calibration_robustness.csv` | `calibrate_fold.py`, `run_robustness.py` |
| Table 10 and Figure 8 | `statistics/paired_comparisons.csv`, bootstrap arrays | `run_statistics.py` |
| Table 11 | `interpretability/probes.csv`, `efficiency/benchmark.json` | evaluation utilities |

`scripts/make_figures.py` renders Figures 3--8 from standardized copies of these
tables. Its default source is the explicitly simulated reference directory for
layout checking; archival figures must be regenerated from empirical run outputs.

Values in `logs/simulated_reference/` are schema examples and manuscript-aligned reproduction targets. They are not accepted automatically by any evaluation script. Actual commands always write to a user-selected output directory and include provenance metadata.
